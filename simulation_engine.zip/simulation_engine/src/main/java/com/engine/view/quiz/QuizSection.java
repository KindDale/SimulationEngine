    package com.engine.view.quiz;

    import javafx.application.Platform;
    import javafx.geometry.Insets;
    import javafx.geometry.Pos;
    import javafx.scene.Scene;
    import javafx.scene.control.Button;
    import javafx.scene.control.Label;
    import javafx.scene.image.Image;
    import javafx.scene.layout.*;
    import javafx.scene.paint.Color;
    import javafx.scene.text.Font;
    import javafx.stage.Stage;


    import org.json.JSONArray;
    import org.json.JSONObject;

    import com.engine.view.UIEffects;

    public class QuizSection  {

        static Scene scene = new Scene(null); 

        private Quiz[] quizSet;
        private int currentQuestionIndex = 0;
        private int score = 0;

        private final Button[] optionButtons = new Button[4];
        private final Label questionText = new Label();
        private final Label scoreLabel = new Label("Score: 0");

        private Stage primaryStage; // We'll need this for later use


        public Scene createQuizScene(){
            // this.primaryStage = primaryStage;
            fetchQuizData(); 
            return scene;
        }

        private void fetchQuizData() {
            Thread fetchThread = new Thread(() -> {
                try {
                    String json = QuizApi.getQuiz();
                    if (json != null && !json.isEmpty()) {
                        Quiz[] quizzes = parseQuizzesFromJson(json);
                        Platform.runLater(() -> {
                            this.quizSet = quizzes;
                            this.currentQuestionIndex = 0;
                            if (quizSet != null && quizSet.length > 0) {
                                buildAndShowUI();
                            } else {
                                showError("No quiz data found.");
                            }
                        });
                    } else {
                        Platform.runLater(() -> showError("Quiz API returned empty data."));
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Platform.runLater(() -> showError("Error fetching quiz data."));
                }
            });
            fetchThread.setDaemon(true);
            fetchThread.start();
        }

        // Builds full UI after data is loaded
        private void buildAndShowUI() {
            BorderPane root = new BorderPane();

            Image bgImage = new Image("Assets/Images/back.png");
            BackgroundImage backgroundImage = new BackgroundImage(
                bgImage,
                BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.DEFAULT,
                new BackgroundSize(100, 100, true, true, true, false)
            );
            root.setBackground(new Background(backgroundImage));

            // LEFT PANEL
            VBox leftPanel = new VBox(15);
            leftPanel.setAlignment(Pos.CENTER);
            leftPanel.setPadding(new Insets(20));
            leftPanel.setPrefWidth(250);
            leftPanel.setStyle("-fx-background-color: rgba(0, 0, 0, 0.3); -fx-background-radius: 10;");

            for (int i = 0; i < quizSet.length; i++) {
                Button qButton = new Button(String.format("%02d Question", i + 1));
                UIEffects.applyButtonHoverEffect(qButton);
                qButton.setMaxWidth(Double.MAX_VALUE);
                qButton.setStyle("-fx-background-color: #ffffff44; -fx-text-fill: white; -fx-font-size: 13px; -fx-background-radius: 8;");
                leftPanel.getChildren().add(qButton);
            }

            // CENTER PANEL
            VBox centerPanel = new VBox(20);
            centerPanel.setAlignment(Pos.CENTER);
            centerPanel.setPadding(new Insets(40));

            questionText.setFont(new Font("Arial", 20));
            questionText.setTextFill(Color.WHITE);
            questionText.setWrapText(true);

            VBox optionsBox = new VBox(10);
            optionsBox.setAlignment(Pos.CENTER);
            for (int i = 0; i < 4; i++) {
                Button btn = new Button();
                UIEffects.applyButtonHoverEffect(btn);
                btn.setFont(Font.font(14));
                btn.setMaxWidth(400);
                btn.setMinHeight(40);
                btn.setTextFill(Color.WHITE);
                btn.setStyle("-fx-background-color: rgba(255,255,255,0.2); -fx-background-radius: 10;");
                btn.setOnAction(e -> handleAnswer(btn.getText()));
                optionButtons[i] = btn;
                optionsBox.getChildren().add(btn);
            }

            scoreLabel.setFont(Font.font(16));
            scoreLabel.setTextFill(Color.WHITE);
            centerPanel.getChildren().addAll(questionText, optionsBox, scoreLabel);

            root.setLeft(leftPanel);
            root.setCenter(centerPanel);

            scene = new Scene(root, 1048, 700);
            primaryStage.setScene(scene);
            primaryStage.setTitle("Quiz App");
            primaryStage.show();

            loadQuestion(); // Load first question after UI is ready
        }

        private void loadQuestion() {
            if (quizSet == null || currentQuestionIndex >= quizSet.length) {
                return;
            }

            Quiz q = quizSet[currentQuestionIndex];
            questionText.setText(q.question);
            for (int i = 0; i < 4; i++) {
                optionButtons[i].setText(q.options[i]);
                optionButtons[i].setDisable(false);
                optionButtons[i].setStyle("-fx-background-color: rgba(255,255,255,0.2); -fx-text-fill: white; -fx-font-size: 14px; -fx-background-radius: 10;");
            }
        }

        private void handleAnswer(String selectedOption) {
            Quiz q = quizSet[currentQuestionIndex];
            boolean isCorrect = selectedOption.equals(q.correctAnswer);
            if (isCorrect) score++;

            for (Button btn : optionButtons) {
                btn.setDisable(true);
                if (btn.getText().equals(q.correctAnswer)) {
                    btn.setStyle("-fx-background-color: #00C853; -fx-text-fill: white; -fx-background-radius: 10;");
                } else if (btn.getText().equals(selectedOption)) {
                    btn.setStyle("-fx-background-color: #D50000; -fx-text-fill: white; -fx-background-radius: 10;");
                }
            }

            scoreLabel.setText("Score: " + score);

            currentQuestionIndex++;
            if (currentQuestionIndex < quizSet.length) {
                new Thread(() -> {
                    try { Thread.sleep(1200); } catch (InterruptedException ignored) {}
                    Platform.runLater(this::loadQuestion);
                }).start();
            }
        }

        private void showError(String message) {
            Label errorLabel = new Label(message);
            errorLabel.setTextFill(Color.RED);
            errorLabel.setFont(Font.font(18));
            StackPane pane = new StackPane(errorLabel);
            Scene scene = new Scene(pane, 600, 200);
            primaryStage.setScene(scene);
            primaryStage.setTitle("Error");
            primaryStage.show();
        }

        private Quiz[] parseQuizzesFromJson(String json) {
            JSONArray quizArray = new JSONArray(json);
            int numQuizzes = quizArray.length();
            Quiz[] quizzes = new Quiz[numQuizzes];
            for (int i = 0; i < numQuizzes; i++) {
                JSONObject quizObject = quizArray.getJSONObject(i);
                String question = quizObject.getString("question");

                JSONArray incorrectAnswers = quizObject.getJSONArray("incorrectAnswers");
                int optionCount = incorrectAnswers.length() + 1;
                String[] options = new String[optionCount];
                for (int j = 0; j < incorrectAnswers.length(); j++) {
                    options[j] = incorrectAnswers.getString(j);
                }
                options[incorrectAnswers.length()] = quizObject.getString("correctAnswer"); // last

                options = shuffleArray(options);
                String correctAnswer = quizObject.getString("correctAnswer");
                quizzes[i] = new Quiz(question, options, correctAnswer);
            }
            return quizzes;
        }

        private String[] shuffleArray(String[] arr) {
            for (int i = arr.length - 1; i > 0; i--) {
                int j = (int) (Math.random() * (i + 1));
                String temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
            return arr;
        }

        static class Quiz {
            String question;
            String[] options;
            String correctAnswer;

            public Quiz(String question, String[] options, String correctAnswer) {
                this.question = question;
                this.options = options;
                this.correctAnswer = correctAnswer;
            }
        }
    }