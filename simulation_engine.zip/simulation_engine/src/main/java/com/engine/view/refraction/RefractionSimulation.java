package com.engine.view.refraction;

import javafx.animation.AnimationTimer;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class RefractionSimulation {
    private double incidentAngleDeg;
    private double n1;
    private double n2;
    private final GraphicsContext gc;
    private final Canvas canvas;
    private AnimationTimer timer;

    public RefractionSimulation(double incidentAngleDeg, double n1, double n2, GraphicsContext gc, Canvas canvas) {
        this.incidentAngleDeg = incidentAngleDeg;
        this.n1 = n1;
        this.n2 = n2;
        this.gc = gc;
        this.canvas = canvas;
    }

    public void start() {
        timer = new AnimationTimer() {
            private double t = 0;
            private final double rayLen = 140;

            @Override
            public void handle(long now) {

                t += 0.016;
                double partial = Math.min(1, t);

                gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());

                double pivotX = canvas.getWidth() / 2;
                double pivotY = canvas.getHeight() * 0.65;

                gc.setStroke(Color.BLACK);
                gc.setLineWidth(2);
                gc.strokeLine(0, pivotY, canvas.getWidth(), pivotY);

                double incidentRad = Math.toRadians(incidentAngleDeg);
                double sinRefracted = (n1 / n2) * Math.sin(incidentRad);
                boolean tir = Math.abs(sinRefracted) > 1;
                double refractedRad = tir ? 0 : Math.asin(sinRefracted);

                // Start point (outside medium)
                double startX = pivotX - rayLen * Math.cos(incidentRad);
                double startY = pivotY - rayLen * Math.sin(incidentRad);
                // Animated endpoint (moves toward black line at pivot)
                double endX = startX + rayLen * Math.cos(incidentRad) * partial;
                double endY = startY + rayLen * Math.sin(incidentRad) * partial;

                    

                // double incidentX = pivotX - rayLen * Math.cos(incidentRad) * partial;
                // double incidentY = pivotY - rayLen * Math.sin(incidentRad) * partial;

                gc.setStroke(Color.ORANGE);
                gc.setLineWidth(3);
                gc.strokeLine(startX, startY, endX, endY);
                //gc.strokeLine(pivotX, pivotY, incidentX, incidentY);

                if (tir) {
                    double reflectedX = pivotX + rayLen * Math.cos(incidentRad);
                    double reflectedY = pivotY - rayLen * Math.sin(incidentRad);
                    gc.setStroke(Color.RED);
                    gc.strokeLine(pivotX, pivotY, reflectedX, reflectedY);
                } else {
                    double refractedX = pivotX + rayLen * Math.cos(refractedRad);
                    double refractedY = pivotY + rayLen * Math.sin(refractedRad);
                    gc.setStroke(Color.BLUE);
                    gc.strokeLine(pivotX, pivotY, refractedX, refractedY);
                }

                gc.setStroke(Color.GRAY);
                gc.setLineDashes(5);
                gc.strokeLine(pivotX, pivotY - 70, pivotX, pivotY + 100);
                gc.setLineDashes(0);

                if (partial >= 1) 
                    t = 1;
            }
        };
        timer.start();
    }

    public void stop() {
        if (timer != null) {
            timer.stop();
        }
    }
}
