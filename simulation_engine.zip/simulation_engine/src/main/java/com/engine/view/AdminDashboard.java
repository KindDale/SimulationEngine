package com.engine.view;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class AdminDashboard extends Application {
    
    // Inner class for Quiz Questions
    public static class QuizQuestion {
        private String question;
        private String difficulty;
        private String topic;
        private String status;
        
        public QuizQuestion(String question, String difficulty, String topic, String status) {
            this.question = question;
            this.difficulty = difficulty;
            this.topic = topic;
            this.status = status;
        }
        
        // Getters and setters
        public String getQuestion() { return question; }
        public void setQuestion(String question) { this.question = question; }
        public String getDifficulty() { return difficulty; }
        public void setDifficulty(String difficulty) { this.difficulty = difficulty; }
        public String getTopic() { return topic; }
        public void setTopic(String topic) { this.topic = topic; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
    }
    
    @Override
    public void start(Stage primaryStage) {
        // Create main container
        BorderPane root = new BorderPane();
        
        // Set background image
        try {
            Image backgroundImage = new Image("/images/background/bgImage.jpeg");
            BackgroundImage bgImage = new BackgroundImage(
                backgroundImage,
                BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.CENTER,
                new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, true)
            );
            root.setBackground(new Background(bgImage));
        } catch (Exception e) {
            // Fallback gradient background
            root.setStyle("-fx-background: linear-gradient(to right, #4facfe 0%, #00f2fe 100%);");
        }
        
        // Create sidebar
        VBox sidebar = createSidebar();
        root.setLeft(sidebar);
        
        // Create main content
        VBox mainContent = createMainContent();
        root.setCenter(mainContent);
        
        // Create scene
        Scene scene = new Scene(root, 1048, 700);
        
        // Apply inline CSS styles
        scene.getRoot().setStyle("-fx-font-family: 'Segoe UI', Arial, sans-serif;");
        
        primaryStage.setTitle("Physics Simulation - Admin Dashboard");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    private VBox createSidebar() {
        VBox sidebar = new VBox(20);
        sidebar.setPadding(new Insets(30, 20, 30, 30));
        sidebar.setPrefWidth(280);
        sidebar.setStyle("-fx-background-color: rgba(255, 255, 255, 0.1); -fx-background-radius: 0 20 20 0;");
        
        // Logo and title
        HBox logoSection = new HBox(15);
        logoSection.setAlignment(Pos.CENTER_LEFT);
        
        // Create a simple cube icon
        Label cubeIcon = new Label("⬜");
        cubeIcon.setStyle("-fx-text-fill: white; -fx-font-size: 24px;");
        
        VBox titleSection = new VBox(2);
        Label projectsLabel = new Label("Projects");
        projectsLabel.setStyle("-fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold;");
        Label subtitleLabel = new Label("Suanmotr.high");
        subtitleLabel.setStyle("-fx-text-fill: rgba(255, 255, 255, 0.8); -fx-font-size: 12px;");
        titleSection.getChildren().addAll(projectsLabel, subtitleLabel);
        
        logoSection.getChildren().addAll(cubeIcon, titleSection);
        
        // Create separator
        Separator separator = new Separator();
        separator.setStyle("-fx-background-color: rgba(255, 255, 255, 0.3);");
        
        // Navigation items
        VBox navItems = new VBox(15);
        navItems.getChildren().addAll(
            createNavItem("📊", "Dashboard", true),
            createNavItem("🔬", "Simulations", false),
            createNavItem("⚗", "Experiments", false),
            createNavItem("📖", "Guideate", false),
            createNavItem("👥", "Community", false)
        );
        
        sidebar.getChildren().addAll(logoSection, separator, navItems);
        return sidebar;
    }
    
    private HBox createNavItem(String icon, String text, boolean isActive) {
        HBox navItem = new HBox(15);
        navItem.setAlignment(Pos.CENTER_LEFT);
        navItem.setPadding(new Insets(12, 15, 12, 15));
        
        if (isActive) {
            navItem.setStyle("-fx-background-color: rgba(255, 255, 255, 0.2); -fx-background-radius: 10; -fx-cursor: hand;");
        } else {
            navItem.setStyle("-fx-background-color: transparent; -fx-cursor: hand;");
        }
        
        Label iconLabel = new Label(icon);
        iconLabel.setStyle("-fx-text-fill: white; -fx-font-size: 16px;");
        
        Label textLabel = new Label(text);
        textLabel.setStyle("-fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: " + 
                         (isActive ? "bold" : "normal") + ";");
        
        navItem.getChildren().addAll(iconLabel, textLabel);
        
        // Add hover effect
        navItem.setOnMouseEntered(e -> {
            if (!isActive) {
                navItem.setStyle("-fx-background-color: rgba(255, 255, 255, 0.1); -fx-background-radius: 10; -fx-cursor: hand;");
            }
        });
        
        navItem.setOnMouseExited(e -> {
            if (!isActive) {
                navItem.setStyle("-fx-background-color: transparent; -fx-cursor: hand;");
            }
        });
        
        return navItem;
    }
    
    private VBox createMainContent() {
        VBox mainContent = new VBox(30);
        mainContent.setPadding(new Insets(40, 40, 40, 20));
        
        // Title
        Label titleLabel = new Label("Admin Dashboard");
        titleLabel.setStyle("-fx-text-fill: white; -fx-font-size: 48px; -fx-font-weight: bold;");
        titleLabel.setAlignment(Pos.CENTER);
        
        // Feature cards container
        HBox topRow = new HBox(30);
        topRow.setAlignment(Pos.CENTER);
        
        VBox quizCard = createFeatureCard(
            "Quiz Updating",
            "Manage and update quiz questions, answers, and difficulty levels for the physics simulation engine.",
            this::openQuizManager
        );
        
        VBox communityCard = createFeatureCard(
            "Community Creation Requests",
            "Review and approve new community creation requests from users wanting to start physics discussion groups.",
            this::openCommunityRequests
        );
        
        topRow.getChildren().addAll(quizCard, communityCard);
        
        // Bottom row
        HBox bottomRow = new HBox(30);
        bottomRow.setAlignment(Pos.CENTER);
        
        VBox reportedCard = createFeatureCard(
            "Reported Messages",
            "Review reported messages from community sections and take appropriate moderation actions.",
            this::openReportedMessages
        );
        
        bottomRow.getChildren().add(reportedCard);
        
        mainContent.getChildren().addAll(titleLabel, topRow, bottomRow);
        return mainContent;
    }
    
    private VBox createFeatureCard(String title, String description, Runnable action) {
        VBox card = new VBox(20);
        card.setPadding(new Insets(30));
        card.setPrefWidth(350);
        card.setPrefHeight(200);
        card.setStyle("-fx-background-color: rgba(255, 255, 255, 0.15); " +
                     "-fx-background-radius: 15; " +
                     "-fx-border-radius: 15; " +
                     "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 10, 0, 0, 5); " +
                     "-fx-cursor: hand;");
        
        Label titleLabel = new Label(title);
        titleLabel.setStyle("-fx-text-fill: white; -fx-font-size: 22px; -fx-font-weight: bold;");
        titleLabel.setWrapText(true);
        
        Label descLabel = new Label(description);
        descLabel.setStyle("-fx-text-fill: rgba(255, 255, 255, 0.9); -fx-font-size: 14px;");
        descLabel.setWrapText(true);
        
        Button actionButton = new Button("Open");
        actionButton.setStyle("-fx-background-color: rgba(255, 255, 255, 0.3); " +
                             "-fx-text-fill: white; " +
                             "-fx-font-size: 12px; " +
                             "-fx-font-weight: bold; " +
                             "-fx-background-radius: 20; " +
                             "-fx-padding: 8 16 8 16; " +
                             "-fx-cursor: hand;");
        
        // Button hover effects
        actionButton.setOnMouseEntered(e -> {
            actionButton.setStyle("-fx-background-color: rgba(255, 255, 255, 0.4); " +
                                 "-fx-text-fill: white; " +
                                 "-fx-font-size: 12px; " +
                                 "-fx-font-weight: bold; " +
                                 "-fx-background-radius: 20; " +
                                 "-fx-padding: 8 16 8 16; " +
                                 "-fx-cursor: hand;");
        });
        
        actionButton.setOnMouseExited(e -> {
            actionButton.setStyle("-fx-background-color: rgba(255, 255, 255, 0.3); " +
                                 "-fx-text-fill: white; " +
                                 "-fx-font-size: 12px; " +
                                 "-fx-font-weight: bold; " +
                                 "-fx-background-radius: 20; " +
                                 "-fx-padding: 8 16 8 16; " +
                                 "-fx-cursor: hand;");
        });
        
        actionButton.setOnAction(e -> action.run());
        
        // Card hover effects
        card.setOnMouseEntered(e -> {
            card.setStyle("-fx-background-color: rgba(255, 255, 255, 0.25); " +
                         "-fx-background-radius: 15; " +
                         "-fx-border-radius: 15; " +
                         "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 15, 0, 0, 8); " +
                         "-fx-cursor: hand;");
        });
        
        card.setOnMouseExited(e -> {
            card.setStyle("-fx-background-color: rgba(255, 255, 255, 0.15); " +
                         "-fx-background-radius: 15; " +
                         "-fx-border-radius: 15; " +
                         "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 10, 0, 0, 5); " +
                         "-fx-cursor: hand;");
        });
        
        card.getChildren().addAll(titleLabel, descLabel, actionButton);
        return card;
    }
    
    // Quiz Manager Implementation
    private void openQuizManager() {
        Stage stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Quiz Manager - Physics Simulation Engine");
        
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background: linear-gradient(to right, #4facfe 0%, #00f2fe 100%);");
        
        // Header
        VBox header = new VBox(10);
        header.setPadding(new Insets(20));
        header.setAlignment(Pos.CENTER);
        
        Label headerTitle = new Label("Quiz Management System");
        headerTitle.setStyle("-fx-text-fill: white; -fx-font-size: 24px; -fx-font-weight: bold;");
        
        Label headerSubtitle = new Label("Manage physics quiz questions and difficulty levels");
        headerSubtitle.setStyle("-fx-text-fill: rgba(255, 255, 255, 0.8); -fx-font-size: 14px;");
        
        header.getChildren().addAll(headerTitle, headerSubtitle);
        
        // Create table
        TableView<QuizQuestion> table = new TableView<>();
        table.setStyle("-fx-background-color: rgba(255, 255, 255, 0.9); " +
                      "-fx-background-radius: 10; " +
                      "-fx-padding: 10;");
        
        TableColumn<QuizQuestion, String> questionCol = new TableColumn<>("Question");
        questionCol.setCellValueFactory(new PropertyValueFactory<>("question"));
        questionCol.setPrefWidth(300);
        
        TableColumn<QuizQuestion, String> difficultyCol = new TableColumn<>("Difficulty");
        difficultyCol.setCellValueFactory(new PropertyValueFactory<>("difficulty"));
        difficultyCol.setPrefWidth(100);
        
        TableColumn<QuizQuestion, String> topicCol = new TableColumn<>("Topic");
        topicCol.setCellValueFactory(new PropertyValueFactory<>("topic"));
        topicCol.setPrefWidth(150);
        
        TableColumn<QuizQuestion, String> statusCol = new TableColumn<>("Status");
        statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));
        statusCol.setPrefWidth(100);
        
        table.getColumns().addAll(questionCol, difficultyCol, topicCol, statusCol);
        
        // Sample physics quiz data
        ObservableList<QuizQuestion> data = FXCollections.observableArrayList(
            new QuizQuestion("What is Newton's first law of motion?", "Easy", "Classical Mechanics", "Active"),
            new QuizQuestion("Calculate the momentum of a 5kg object moving at 10m/s", "Medium", "Classical Mechanics", "Active"),
            new QuizQuestion("What is the principle of superposition in quantum mechanics?", "Hard", "Quantum Physics", "Draft"),
            new QuizQuestion("What is the speed of light in vacuum?", "Easy", "Optics", "Active"),
            new QuizQuestion("Derive the equation for simple harmonic motion", "Hard", "Oscillations", "Active"),
            new QuizQuestion("What is Ohm's law?", "Easy", "Electricity", "Active"),
            new QuizQuestion("Explain the photoelectric effect", "Medium", "Modern Physics", "Draft"),
            new QuizQuestion("Calculate the gravitational force between two masses", "Medium", "Gravitation", "Active")
        );
        
        table.setItems(data);
        
        // Control buttons
        HBox buttonBox = new HBox(15);
        buttonBox.setPadding(new Insets(20));
        buttonBox.setAlignment(Pos.CENTER);
        
        Button addBtn = new Button("Add New Question");
        Button editBtn = new Button("Edit Selected");
        Button deleteBtn = new Button("Delete Selected");
        Button previewBtn = new Button("Preview Quiz");
        Button exportBtn = new Button("Export Questions");
        
        // Style buttons
        String buttonStyle = "-fx-background-color: rgba(255, 255, 255, 0.3); " +
                           "-fx-text-fill: white; -fx-background-radius: 15; " +
                           "-fx-font-weight: bold; -fx-padding: 10 20 10 20; " +
                           "-fx-cursor: hand;";
        
        addBtn.setStyle(buttonStyle);
        editBtn.setStyle(buttonStyle);
        deleteBtn.setStyle(buttonStyle);
        previewBtn.setStyle(buttonStyle);
        exportBtn.setStyle(buttonStyle);
        
        // Button actions
        addBtn.setOnAction(e -> showAddQuestionDialog(data));
        editBtn.setOnAction(e -> {
            QuizQuestion selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                showEditQuestionDialog(selected);
            } else {
                showAlert("No Selection", "Please select a question to edit.");
            }
        });
        deleteBtn.setOnAction(e -> {
            QuizQuestion selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                data.remove(selected);
            } else {
                showAlert("No Selection", "Please select a question to delete.");
            }
        });
        previewBtn.setOnAction(e -> showQuizPreview(data));
        exportBtn.setOnAction(e -> showAlert("Export", "Quiz questions exported successfully!"));
        
        buttonBox.getChildren().addAll(addBtn, editBtn, deleteBtn, previewBtn, exportBtn);
        
        // Layout
        VBox centerContent = new VBox(10);
        centerContent.setPadding(new Insets(20));
        centerContent.getChildren().add(table);
        
        root.setTop(header);
        root.setCenter(centerContent);
        root.setBottom(buttonBox);
        
        Scene scene = new Scene(root, 900, 700);
        stage.setScene(scene);
        stage.show();
    }
    
    private void showAddQuestionDialog(ObservableList<QuizQuestion> data) {
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("Add New Quiz Question");
        
        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        content.setStyle("-fx-background: linear-gradient(to right, #667eea 0%, #764ba2 100%);");
        
        Label title = new Label("Add New Physics Question");
        title.setStyle("-fx-text-fill: white; -fx-font-size: 18px; -fx-font-weight: bold;");
        
        TextArea questionArea = new TextArea();
        questionArea.setPromptText("Enter the physics question...");
        questionArea.setPrefRowCount(3);
        
        ComboBox<String> difficultyBox = new ComboBox<>();
        difficultyBox.getItems().addAll("Easy", "Medium", "Hard");
        difficultyBox.setPromptText("Select difficulty level");
        
        ComboBox<String> topicBox = new ComboBox<>();
        topicBox.getItems().addAll("Classical Mechanics", "Quantum Physics", "Optics", 
                                  "Electricity", "Magnetism", "Thermodynamics", 
                                  "Modern Physics", "Oscillations", "Gravitation");
        topicBox.setPromptText("Select physics topic");
        
        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER);
        
        Button saveBtn = new Button("Save Question");
        Button cancelBtn = new Button("Cancel");
        
        saveBtn.setStyle("-fx-background-color: rgba(255, 255, 255, 0.3); -fx-text-fill: white; -fx-background-radius: 10;");
        cancelBtn.setStyle("-fx-background-color: rgba(255, 255, 255, 0.3); -fx-text-fill: white; -fx-background-radius: 10;");
        
        saveBtn.setOnAction(e -> {
            if (!questionArea.getText().trim().isEmpty() && 
                difficultyBox.getValue() != null && 
                topicBox.getValue() != null) {
                
                data.add(new QuizQuestion(
                    questionArea.getText().trim(),
                    difficultyBox.getValue(),
                    topicBox.getValue(),
                    "Active"
                ));
                dialog.close();
            } else {
                showAlert("Incomplete Data", "Please fill in all fields.");
            }
        });
        
        cancelBtn.setOnAction(e -> dialog.close());
        
        buttonBox.getChildren().addAll(saveBtn, cancelBtn);
        content.getChildren().addAll(title, new Label("Question:"), questionArea, 
                                    new Label("Difficulty:"), difficultyBox,
                                    new Label("Topic:"), topicBox, buttonBox);
        
        Scene scene = new Scene(content, 400, 350);
        dialog.setScene(scene);
        dialog.show();
    }
    
    private void showEditQuestionDialog(QuizQuestion question) {
        showAlert("Edit Question", "Edit functionality for: " + question.getQuestion());
    }
    
    private void showQuizPreview(ObservableList<QuizQuestion> data) {
        StringBuilder preview = new StringBuilder("Quiz Preview:\n\n");
        int count = 1;
        for (QuizQuestion q : data) {
            if ("Active".equals(q.getStatus())) {
                preview.append(count++).append(". ").append(q.getQuestion())
                       .append("\n   Topic: ").append(q.getTopic())
                       .append(" | Difficulty: ").append(q.getDifficulty()).append("\n\n");
            }
        }
        showAlert("Quiz Preview", preview.toString());
    }
    
    // Community Creation Requests Implementation
    private void openCommunityRequests() {
        Stage stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Community Creation Requests");
        
        VBox content = new VBox(20);
        content.setPadding(new Insets(30));
        content.setStyle("-fx-background: linear-gradient(to right, #667eea 0%, #764ba2 100%);");
        
        Label title = new Label("Pending Community Creation Requests");
        title.setStyle("-fx-text-fill: white; -fx-font-size: 24px; -fx-font-weight: bold;");
        
        // Create request cards
        VBox requestsContainer = new VBox(15);
        
        requestsContainer.getChildren().addAll(
            createRequestCard("Physics Study Group", "John Doe", "A group for undergraduate physics students to discuss homework and concepts", "2 days ago"),
            createRequestCard("Quantum Mechanics Discussion", "Jane Smith", "Advanced discussion forum for quantum mechanics topics and research", "1 day ago"),
            createRequestCard("Classical Mechanics Help", "Mike Johnson", "Help forum for classical mechanics problems and solutions", "3 hours ago"),
            createRequestCard("Experimental Physics Lab", "Sarah Wilson", "Community for sharing experimental setups and results", "1 hour ago")
        );
        
        ScrollPane scrollPane = new ScrollPane(requestsContainer);
        scrollPane.setStyle("-fx-background: transparent; -fx-background-color: transparent;");
        scrollPane.setPrefHeight(400);
        
        content.getChildren().addAll(title, scrollPane);
        
        Scene scene = new Scene(content, 700, 600);
        stage.setScene(scene);
        stage.show();
    }
    
    private VBox createRequestCard(String communityName, String requester, String description, String timeAgo) {
        VBox card = new VBox(10);
        card.setPadding(new Insets(20));
        card.setStyle("-fx-background-color: rgba(255, 255, 255, 0.2); " +
                     "-fx-background-radius: 10; " +
                     "-fx-border-radius: 10;");
        
        Label nameLabel = new Label(communityName);
        nameLabel.setStyle("-fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold;");
        
        Label requesterLabel = new Label("Requested by: " + requester + " • " + timeAgo);
        requesterLabel.setStyle("-fx-text-fill: rgba(255, 255, 255, 0.8); -fx-font-size: 12px;");
        
        Label descLabel = new Label(description);
        descLabel.setStyle("-fx-text-fill: rgba(255, 255, 255, 0.9); -fx-font-size: 14px;");
        descLabel.setWrapText(true);
        
        HBox buttonBox = new HBox(10);
        Button approveBtn = new Button("Approve");
        Button denyBtn = new Button("Deny");
        Button detailsBtn = new Button("View Details");
        
        approveBtn.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-background-radius: 5;");
        denyBtn.setStyle("-fx-background-color: #f44336; -fx-text-fill: white; -fx-background-radius: 5;");
        detailsBtn.setStyle("-fx-background-color: rgba(255, 255, 255, 0.3); -fx-text-fill: white; -fx-background-radius: 5;");
        
        approveBtn.setOnAction(e -> showAlert("Approved", "Community '" + communityName + "' has been approved!"));
        denyBtn.setOnAction(e -> showAlert("Denied", "Community '" + communityName + "' has been denied."));
        detailsBtn.setOnAction(e -> showAlert("Details", "Detailed information for: " + communityName));
        
        buttonBox.getChildren().addAll(approveBtn, denyBtn, detailsBtn);
        card.getChildren().addAll(nameLabel, requesterLabel, descLabel, buttonBox);
        
        return card;
    }
    
    // Reported Messages Implementation
    private void openReportedMessages() {
        Stage stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Reported Messages - Moderation Panel");
        
        VBox content = new VBox(20);
        content.setPadding(new Insets(30));
        content.setStyle("-fx-background: linear-gradient(to right, #667eea 0%, #764ba2 100%);");
        
        Label title = new Label("Reported Messages & Content Moderation");
        title.setStyle("-fx-text-fill: white; -fx-font-size: 24px; -fx-font-weight: bold;");
        
        // Create reported message cards
        VBox reportsContainer = new VBox(15);
        
        reportsContainer.getChildren().addAll(
            createReportCard("Inappropriate Language", "General Discussion", "User posted offensive content in physics discussion", "High", "2 hours ago"),
            createReportCard("Spam Content", "Homework Help", "Multiple promotional links posted by same user", "Medium", "4 hours ago"),
            createReportCard("Off-topic Discussion", "Advanced Physics", "Non-physics related conversation in quantum mechanics thread", "Low", "1 day ago"),
            createReportCard("Harassment", "Community Chat", "User reported for personal attacks and harassment", "High", "30 minutes ago"),
            createReportCard("Misinformation", "Physics Facts", "Incorrect physics information being spread as fact", "Medium", "6 hours ago")
        );
        
        ScrollPane scrollPane = new ScrollPane(reportsContainer);
        scrollPane.setStyle("-fx-background: transparent; -fx-background-color: transparent;");
        scrollPane.setPrefHeight(450);
        
        content.getChildren().addAll(title, scrollPane);
        
        Scene scene = new Scene(content, 800, 650);
        stage.setScene(scene);
        stage.show();
    }
    
    private VBox createReportCard(String reportType, String location, String description, String priority, String timeAgo) {
        VBox card = new VBox(12);
        card.setPadding(new Insets(20));
        card.setStyle("-fx-background-color: rgba(255, 255, 255, 0.2); " +
                     "-fx-background-radius: 10; " +
                     "-fx-border-radius: 10;");
        
        HBox headerBox = new HBox();
        headerBox.setAlignment(Pos.CENTER_LEFT);
        headerBox.setSpacing(10);
        
        Label typeLabel = new Label(reportType);
        typeLabel.setStyle("-fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold;");
        
        Label priorityLabel = new Label(priority + " Priority");
        String priorityColor = priority.equals("High") ? "#ff4444" : 
                              priority.equals("Medium") ? "#ffaa00" : "#44ff44";
        priorityLabel.setStyle("-fx-background-color: " + priorityColor + "; " +
                              "-fx-text-fill: white; -fx-padding: 2 8 2 8; " +
                              "-fx-background-radius: 10; -fx-font-size: 10px;");
        
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        
        Label timeLabel = new Label(timeAgo);
        timeLabel.setStyle("-fx-text-fill: rgba(255, 255, 255, 0.7); -fx-font-size: 12px;");
        
        headerBox.getChildren().addAll(typeLabel, priorityLabel, spacer, timeLabel);
        
        Label locationLabel = new Label("Location: " + location);
        locationLabel.setStyle("-fx-text-fill: rgba(255, 255, 255, 0.8); -fx-font-size: 12px; -fx-font-style: italic;");
        
        Label descLabel = new Label(description);
        descLabel.setStyle("-fx-text-fill: rgba(255, 255, 255, 0.9); -fx-font-size: 14px;");
        descLabel.setWrapText(true);
        
        HBox actionBox = new HBox(10);
        Button resolveBtn = new Button("Mark Resolved");
        Button warnBtn = new Button("Warn User");
        Button banBtn = new Button("Ban User");
        Button viewBtn = new Button("View Full Report");
        
        resolveBtn.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-background-radius: 5; -fx-padding: 5 10 5 10;");
        warnBtn.setStyle("-fx-background-color: #FF9800; -fx-text-fill: white; -fx-background-radius: 5; -fx-padding: 5 10 5 10;");
        banBtn.setStyle("-fx-background-color: #f44336; -fx-text-fill: white; -fx-background-radius: 5; -fx-padding: 5 10 5 10;");
        viewBtn.setStyle("-fx-background-color: rgba(255, 255, 255, 0.3); -fx-text-fill: white; -fx-background-radius: 5; -fx-padding: 5 10 5 10;");
        
        resolveBtn.setOnAction(e -> showAlert("Resolved", "Report '" + reportType + "' has been marked as resolved."));
        warnBtn.setOnAction(e -> showAlert("Warning Sent", "Warning has been sent to the reported user."));
        banBtn.setOnAction(e -> showAlert("User Banned", "User has been banned for: " + reportType));
        viewBtn.setOnAction(e -> showAlert("Full Report", "Detailed report for: " + reportType + "\n\nThis would show the full conversation thread, user history, and additional context."));
        
        actionBox.getChildren().addAll(resolveBtn, warnBtn, banBtn, viewBtn);
        card.getChildren().addAll(headerBox, locationLabel, descLabel, actionBox);
        
        return card;
    }
    
    // Utility method for showing alerts
    private void showAlert(String title, String content) {
        Alert dialog = new Alert(Alert.AlertType.INFORMATION);
        dialog.setTitle(title);
        dialog.setHeaderText(title);
        dialog.setContentText(content);
        
        // Style the dialog
        DialogPane dialogPane = dialog.getDialogPane();
        dialogPane.setStyle("-fx-background-color: linear-gradient(to right, #667eea 0%, #764ba2 100%);");
        
        // Style dialog text
        dialogPane.lookup(".content.label").setStyle("-fx-text-fill: white;");
        dialogPane.lookup(".header-panel").setStyle("-fx-background-color: transparent;");
        dialogPane.lookup(".header-panel .label").setStyle("-fx-text-fill: white; -fx-font-weight: bold;");
        
        // Style buttons
        dialogPane.lookupAll(".button").forEach(node -> {
            if (node instanceof Button) {
                node.setStyle("-fx-background-color: rgba(255, 255, 255, 0.3); " +
                             "-fx-text-fill: white; -fx-background-radius: 15;");
            }
        });
        
        dialog.showAndWait();
    }
    
    public static void main(String[] args) {
        launch(args);
    }
}