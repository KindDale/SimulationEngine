package com.engine.view;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class ThumbnailPage extends Application{
    
    Stage primaryStage;

    @Override
    public void start(Stage primaryStage) throws Exception {
        
        this.primaryStage = primaryStage;
        // Load background image
        Image bgImage = new Image(getClass().getResource("/images/background/bgdarksim.png").toExternalForm());
        BackgroundImage backgroundImage = new BackgroundImage(
            bgImage,
            BackgroundRepeat.NO_REPEAT,
            BackgroundRepeat.NO_REPEAT,
            BackgroundPosition.DEFAULT,
            new BackgroundSize(100, 100, true, true, true, false)
        );

        StackPane bg = new StackPane();
        bg.setBackground(new Background(backgroundImage));
        
        ImageView simplePendulumImage = new ImageView(getClass().getResource("/images/simplependulum/simplependulum.png").toExternalForm());
        simplePendulumImage.setFitWidth(200);
        simplePendulumImage.setFitHeight(200);
        
        Text simTitleText = new Text(" Simple Pendulum");
        simTitleText.setFont(new Font(30));
        simTitleText.setStyle("-fx-text-fill: #FFFFFF; -fx-font-weight: bold; ");
        
        Text simDescriptionText = new Text("A simple pendulum is a mass suspended from a fixed point, \n" + 
                                        "swinging freely under gravity. It demonstrates periodic motion,\n" +
                                         "with time dependent on the string's length.");
                                         
        simDescriptionText.setFont(new Font(15));
        simDescriptionText.setStyle("-fx-font-weight: semi-bold; -fx-fill: white");

        VBox simVBox = new VBox(10,simTitleText,simDescriptionText);
        simVBox.setAlignment(Pos.CENTER);
        UIEffects.applyElevationEffect(simVBox);

        Button startButton = new Button("Start Simulation");
        startButton.setStyle(
            "-fx-background-color: linear-gradient(to right, #ff007f, #bf00ff);" +
            "-fx-text-fill: white;" +
            "-fx-font-weight: bold;" +
            "-fx-font-size: 14px;" +
            "-fx-padding: 10 20 10 20;" +
            "-fx-background-radius: 30;" +
            "-fx-cursor: hand;"
        );

        UIEffects.applyButtonHoverEffect(startButton);
        VBox vb = new VBox(20,simVBox,startButton);
        vb.setAlignment(Pos.CENTER);        

        HBox hb = new HBox(20,vb,simplePendulumImage);
        hb.setAlignment(Pos.CENTER);
        bg.getChildren().addAll(hb);

        Scene sc = new Scene(bg,999,665);
        primaryStage.setScene(sc);
        primaryStage.setResizable(false);
        primaryStage.show();
    }
}