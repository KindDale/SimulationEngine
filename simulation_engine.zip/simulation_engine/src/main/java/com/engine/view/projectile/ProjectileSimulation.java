package com.engine.view.projectile;

import javafx.animation.AnimationTimer;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.canvas.Canvas;

public class ProjectileSimulation {
    private double velocity, angleRadians, gravity = 9.8;
    private GraphicsContext gc;
    private Canvas canvas;
    private AnimationTimer timer;

    public ProjectileSimulation(double velocity, double angleDeg, GraphicsContext gc, Canvas canvas) {
        this.velocity = velocity;
        this.angleRadians = Math.toRadians(angleDeg);
        this.gc = gc;
        this.canvas = canvas;
    }

    public void start() {
        timer = new AnimationTimer() {
            private double t = 0;
            @Override
            public void handle(long now) {
                double x = velocity * Math.cos(angleRadians) * t;
                double y = velocity * Math.sin(angleRadians) * t - 0.5 * gravity * t * t;
                double scaledX = x;
                double scaledY = canvas.getHeight() - y - 20;

                gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
                gc.setFill(Color.ORANGE);
                gc.fillOval(scaledX, scaledY, 20, 20);
                
                gc.setLineWidth(5);
                gc.strokeLine(10, 500, 500, 500);
                gc.setStroke(Color.BLACK);
                gc.setLineWidth(5);
                gc.strokeLine(10, 500, 10, 30);
                gc.setStroke(Color.BLACK);
                

                if (scaledY > canvas.getHeight() - 20) {
                    stop();
                }
                t += 0.05;
            }
        };
        timer.start();
    }

    public void stop() {
        if (timer != null) {
            timer.stop();
        }
    }
}

