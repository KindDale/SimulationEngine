package com.engine.controller;

import com.engine.view.HomePage;
import com.engine.view.SimulationThumbnail;
import com.engine.view.pendulum.SimulationPendulum;
import com.engine.view.projectile.SimulationProjectile;
import com.engine.view.refraction.SimulationRefraction;
import com.engine.view.spring.SimulationSpring;

import javafx.scene.Scene;
import javafx.scene.image.ImageView;

public class CreateSimThumbnail {
    
    public Scene initializeSimplePendulum(){
        
        ImageView iv = new ImageView(getClass().getResource("/images/pendulum/pendulum.jpg").toExternalForm());   
        iv.setFitWidth(300);
        iv.setFitHeight(300);
        SimulationThumbnail st = new SimulationThumbnail();
        Scene sc = st.SimulationThumbnailPage(iv, "Simple Pendulum", 
        "A simple pendulum is a mass suspended from a fixed point, \n" + 
        "swinging freely under gravity. It demonstrates periodic motion,\n" + 
        "with time dependent on the string's length.", 
        e -> {
            SimulationPendulum sObj = new SimulationPendulum();
            HomePage.homePageStage.setScene(sObj.createPendulumSimWindow());
        });
        return sc;
    }

    public Scene initializeProjectile(){
        
        ImageView iv = new ImageView(getClass().getResource("/images/projectile/projectile.jpg").toExternalForm());
        iv.setFitWidth(300);
        iv.setFitHeight(300);
        SimulationThumbnail st = new SimulationThumbnail();
        Scene sc = st.SimulationThumbnailPage(iv, "Projectile Motion", 
        "Projectile motion is the curved path an object follows when it is \n" + 
        "hrown or projected near the Earth's surface, moving \n" + 
        "under the influence of gravity alone.",
        e -> {
            SimulationProjectile sObj = new SimulationProjectile();
            HomePage.homePageStage.setScene(sObj.createProjectileSimWindow());
        });
        return sc;
    }

    public Scene initializeSpring(){

        ImageView iv = new ImageView(getClass().getResource("/images/spring/spring.jpg").toExternalForm());
        iv.setFitWidth(300);
        iv.setFitHeight(300);

        SimulationThumbnail st = new SimulationThumbnail();
        Scene sc = st.SimulationThumbnailPage(iv, "Spring Mass", 
        "Spring simulation models the oscillatory motion of a\n"+
        "mass attached to a spring, governed by Hooke's Law.\n",
        e -> {
            SimulationSpring sObj = new SimulationSpring();
            HomePage.homePageStage.setScene(sObj.createSpringSimWindow());
        });
        return sc;
    }

    public Scene initializeRefraction(){
        
        ImageView iv = new ImageView(getClass().getResource("/images/refraction/refraction.jpg").toExternalForm());
        iv.setFitWidth(300);
        iv.setFitHeight(300);
        SimulationThumbnail st = new SimulationThumbnail();
        Scene sc = st.SimulationThumbnailPage(iv, "Refraction of Light", 
        "Refraction is the bending of light as it passes from one\n"+
        "medium to another due to a change in its speed.\n",
        e -> {
            SimulationRefraction sObj = new SimulationRefraction();
            HomePage.homePageStage.setScene(sObj.createRefractionSimWindow());
        });
        return sc;
    }
}
