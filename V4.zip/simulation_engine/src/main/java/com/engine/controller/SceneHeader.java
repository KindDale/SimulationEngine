package com.engine.controller;

import com.engine.view.HomePage;
import com.engine.view.UIEffects;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class SceneHeader {
    
    public Scene createHeaderScene(String titLabel,String subtLabel,String simName,
                                 ImageView thumbnailImage,String meta,
                                 EventHandler<ActionEvent> onStartAction){

        Image bgImage = new Image("/images/background/bgImage.jpeg");

        BackgroundImage backgroundImage = new BackgroundImage(
            bgImage,
            BackgroundRepeat.NO_REPEAT,
            BackgroundRepeat.NO_REPEAT,
            BackgroundPosition.DEFAULT,
            new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, false, true, true)
        );

        Button backButton = new Button("← Back");
        backButton.setStyle(
            "-fx-background-color: linear-gradient(to right, #e275f5ff, #9538e6ff);" +
            "-fx-text-fill: white;" +
            "-fx-font-weight: bold;" +
            "-fx-font-size: 14px;" +
            "-fx-padding: 10 20 10 20;" +
            "-fx-background-radius: 30;" +
            "-fx-cursor: hand;"
        );
        backButton.setOnAction(event -> {
            HomePage.homePageStage.setScene(HomePage.homePageScene);
        });
        ImageView pendulumImage = new ImageView("/images/pendulum/pendulum.jpg");
        pendulumImage.setFitHeight(100);
        pendulumImage.setFitWidth(100);

        Label titleLbl = new Label(titLabel);
        titleLbl.setFont(Font.font("Segoe UI", FontWeight.BOLD, 36));
        titleLbl.setTextFill(Color.WHITE);

        Label subtitleLbl = new Label(subtLabel);
        subtitleLbl.setFont(Font.font("Segoe UI", FontWeight.NORMAL, 20));
        subtitleLbl.setTextFill(Color.WHITE);

        VBox backVBox = new VBox(backButton);
        VBox headerText = new VBox(8);
        headerText.setPadding(new Insets(24, 24, 24, 24));
        headerText.setPrefHeight(100);
        headerText.setStyle("-fx-background-radius: 32;"+
                        "-fx-background-color: linear-gradient(to bottom, #451387ff 60%, #160e1dcc 100%);");
                        
        headerText.getChildren().addAll(backVBox,titleLbl, subtitleLbl);
        headerText.setStyle("-fx-text-fill : white;"+
                         "-fx-font-weight: Bold;"+
                         "-fx-font-size : 14px"+
                         "-fx-background-radius : 25");
     
        headerText.setAlignment(Pos.CENTER);

        VBox list = new VBox(12);
            HBox item = new HBox(16);
            item.setAlignment(Pos.CENTER_LEFT);
            item.setPadding(new Insets(8));
            item.setStyle("-fx-background-color: white; -fx-background-radius: 18;");

            VBox imagePlaceholder = new VBox();
            imagePlaceholder.setPrefSize(60, 60);
            imagePlaceholder.setStyle("-fx-background-color: #eee; -fx-background-radius: 12;");
            imagePlaceholder.getChildren().add(thumbnailImage);

            VBox itemText = new VBox(4);
            Label listItemTitle = new Label(simName);
            listItemTitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));

            Label meta1 = new Label(meta);
            meta1.setTextFill(Color.GRAY);
            meta1.setFont(Font.font(13));

            itemText.setStyle("-fx-background-color: transparent;");
            itemText.getChildren().addAll(listItemTitle, meta1);

            Region spacer = new Region();
            HBox.setHgrow(spacer, Priority.ALWAYS);

            VBox btnVBox = new VBox(8);
            btnVBox.setAlignment(Pos.TOP_RIGHT);

            Button startBtn = createCustomButton("Get Started", onStartAction);
            startBtn.setStyle(
            "-fx-background-color: linear-gradient(to right, #e275f5ff, #9538e6ff);" +
            "-fx-text-fill: white;" +
            "-fx-font-weight: bold;" +
            "-fx-font-size: 14px;" +
            "-fx-padding: 10 20 10 20;" +
            "-fx-background-radius: 30;" +
            "-fx-cursor: hand;"
            );
            btnVBox.getChildren().addAll(startBtn);
            btnVBox.setAlignment(Pos.CENTER_RIGHT);

            item.getChildren().addAll(imagePlaceholder, itemText, spacer, btnVBox);
            list.getChildren().add(item);
        
        list.setBackground(new Background(backgroundImage));
        list.setStyle("-fx-background-radius: 20;");

        ScrollPane scrollPane = new ScrollPane(list);
        scrollPane.setFitToWidth(true);
        scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);

        VBox mainContent = new VBox(24);
        mainContent.setPadding(new Insets(24));
        mainContent.setStyle("-fx-background-radius: 32;" +
                             "-fx-background-color: linear-gradient(to bottom right, rgba(103, 92, 92, 0.11) 0%, rgba(65, 63, 63, 0.45) 100%);" +
                             "-fx-border-radius: 32;" +
                             "-fx-border-color: rgba(255, 255, 255, 0.47);" +
                             "-fx-border-width: 1.8;");

        mainContent.getChildren().addAll(headerText,scrollPane);
        HBox root = new HBox(mainContent);
        root.setAlignment(Pos.BOTTOM_CENTER);
        root.setPadding(new Insets(40));
        root.setBackground(new Background(backgroundImage));

        Scene sc = new Scene(root,1048,665);
        return sc;
    }

    public static Button createCustomButton(String buttonText, EventHandler<ActionEvent> action) {
        Button btn = new Button(buttonText);
        btn.setStyle("-fx-background-color: linear-gradient(to right, #9b08f0ff,#185a9d); -fx-text-fill: white;" +"-fx-font-size: 16px;");
        UIEffects.applyButtonHoverEffect(btn);
        btn.setOnAction(action);
        return btn;
    }
}