package com.engine.dao;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

public class SignUpDao {
    private static final String API_KEY = "AIzaSyCiL5IplBhT0gAYfF3COChkqvBSwrQ1Ydc";
    private static final String FIREBASE_PROJECT_ID = "simulationengine-61a82"; 

    public boolean signingUp(String name, String email, String password) {
        try {
            URL url = new URL("https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=" + API_KEY);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);

            String payload = String.format(
                "{\"email\":\"%s\",\"password\":\"%s\",\"returnSecureToken\":true}",
                email, password
            );

            try (OutputStream os = conn.getOutputStream()) {
                os.write(payload.getBytes());
            }

            int responseCode = conn.getResponseCode();
            if (responseCode == 200) {
                return storeUserData(name, email);
            } else {
                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
                String line;
                while ((line = br.readLine()) != null) {
                    System.out.println(line);
                }
                return false;
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }

    private boolean storeUserData(String name, String email) {
        try {
            URL url = new URL("https://firestore.googleapis.com/v1/projects/" + FIREBASE_PROJECT_ID + "/databases/(default)/documents/users");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);

            String jsonBody = String.format("""
                {
                  \"fields\": {
                    \"name\": { \"stringValue\": \"%s\" },
                    \"email\": { \"stringValue\": \"%s\" }
                  }
                }
                """, name, email);

            try (OutputStream os = conn.getOutputStream()) {
                os.write(jsonBody.getBytes());
            }

            return conn.getResponseCode() == 200;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}