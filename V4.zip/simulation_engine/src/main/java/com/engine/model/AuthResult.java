package com.engine.model; 

public class AuthResult {
    private boolean success;
    private String errorMessage;
    private String idToken; 

    public AuthResult(boolean success, String errorMessage, String idToken) {
        this.success = success;
        this.errorMessage = errorMessage;
        this.idToken = idToken;
    }

    public AuthResult(boolean success, String errorMessage) {
        this(success, errorMessage, null);
    }

    public AuthResult(boolean success) {
        this(success, null, null);
    }

    public boolean isSuccess() {
        return success;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public String getIdToken() {
        return idToken;
    }
}