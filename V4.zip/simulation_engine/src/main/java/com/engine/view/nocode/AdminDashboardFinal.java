package com.engine.view.nocode;

import com.engine.view.UIEffects;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class AdminDashboardFinal extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Background image
        BackgroundImage bgImage = new BackgroundImage(
                new Image("/images/background/bgdarksim.png"),
                BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.DEFAULT,
                new BackgroundSize(100, 100, true, true, true, false)
        );

        BorderPane root = new BorderPane();
        root.setBackground(new Background(bgImage));

        // Left Sidebar
        VBox sidebar = new VBox(20);
        sidebar.setPadding(new Insets(30));
        sidebar.setPrefWidth(200);
        sidebar.setStyle("-fx-background-color: rgba(0,0,0,0.3);");
        sidebar.setAlignment(Pos.TOP_LEFT);

        Label projectTitle = new Label("Admin");
        projectTitle.setTextFill(Color.WHITE);
        projectTitle.setFont(Font.font("Arial", 20));

        Label projectName = new Label("Simulon");
        projectName.setTextFill(Color.LIGHTGRAY);

        Label dashboard = new Label("📋 Dashboard");
        Label simulations = new Label("🧪 Simulations");
        Label experiments = new Label("🔬 Experiments");
        Label guideate = new Label("📘 Guideate");
        Label community = new Label("👥 Community");

        sidebar.getChildren().addAll(projectTitle, projectName, dashboard, simulations, experiments, guideate, community);

        // Center Cards
        HBox topCards = new HBox(20);
        topCards.setPadding(new Insets(30));
        VBox bottomCard = new VBox();
        bottomCard.setPadding(new Insets(30));

        Region quizCard = createCard("Quiz Updating", "Manage and update quiz questions, answers, and difficulty levels for the physics ...");
        UIEffects.applyElevationEffect(quizCard);
        
        Region communityCard = createCard("Community Creation", "Review and approve new community ...");
        UIEffects.applyElevationEffect(communityCard);
        
        Region reportedCard = createCard("Reported Messages", "Review reported messages from community sections and take appropriate moderation ...");
        UIEffects.applyElevationEffect(reportedCard);

        topCards.getChildren().addAll(quizCard, communityCard);
        bottomCard.getChildren().add(reportedCard);

        VBox mainContent = new VBox(20, topCards, bottomCard);
        root.setLeft(sidebar);
        root.setCenter(mainContent);

        Scene scene = new Scene(root, 1048, 700);
        primaryStage.setTitle("Admin Dashboard");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();
    }

    private Region createCard(String title, String description) {
        VBox card = new VBox(10);
        card.setPadding(new Insets(20));
        card.setAlignment(Pos.TOP_LEFT);
        card.setPrefSize(300, 150);
        card.setStyle("-fx-background-color: rgba(255, 255, 255, 0.15); -fx-background-radius: 15;");
        Label titleLabel = new Label(title);
        titleLabel.setTextFill(Color.WHITE);
        titleLabel.setFont(Font.font("Arial", 18));

        Label descLabel = new Label(description);
        descLabel.setTextFill(Color.LIGHTGRAY);
        descLabel.setWrapText(true);

        Button openButton = new Button("Open");
        openButton.setStyle("-fx-background-color: rgba(255,255,255,0.5); -fx-background-radius: 20;");

        card.getChildren().addAll(titleLabel, descLabel, openButton);
        return card;
    }
}
