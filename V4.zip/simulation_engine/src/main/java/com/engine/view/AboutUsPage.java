package com.engine.view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.animation.FadeTransition;
import javafx.animation.TranslateTransition;
import javafx.util.Duration;

public class AboutUsPage{

        Stage stage;
        Scene previousScene;

        public AboutUsPage(Stage stage, Scene pScene) {
        this.stage = stage;
        this.previousScene = pScene;
    }

    public Scene createAboutUs(){
        // Create main container
        BorderPane root = new BorderPane();
        
        // Set background image
        try {
            Image backgroundImage = new Image("/images/background/bgImage.jpeg");
            BackgroundImage bgImage = new BackgroundImage(
                backgroundImage,
                BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.CENTER,
                new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, true)
            );
            root.setBackground(new Background(bgImage));
        } catch (Exception e) {
            // Fallback gradient background
            root.setStyle("-fx-background: linear-gradient(to right, #2D1B69 0%, #8B2C8B 50%, #E91E63 100%);");
        }
        
        // Create header
        VBox header = createHeader();
        root.setTop(header);
        
        // Create main content
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setStyle("-fx-background: transparent; -fx-background-color: transparent;");
        scrollPane.setFitToWidth(true);
        scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        
        Button backBtn = new Button("⬅ Back");
        backBtn.setStyle("-fx-background-color: #333; -fx-text-fill: white; -fx-padding: 8 20 8 20; -fx-font-weight: bold;");
        backBtn.setOnAction(e -> stage.setScene(previousScene )); 

        VBox mainContent = createMainContent();
        mainContent.getChildren().add(backBtn);
        scrollPane.setContent(mainContent);
        root.setCenter(scrollPane);
        
        // Create footer
        // VBox footer = createFooter();
        // root.setBottom(footer);
        
        // Create scene
        Scene scene = new Scene(root, 999, 600);
        scene.getStylesheets().add("data:text/css," + getCustomCSS());
            
        addAnimations(mainContent);
        return scene;
    }
    
    private VBox createHeader() {
        VBox header = new VBox(15);
        header.setPadding(new Insets(30, 50, 20, 50));
        header.setAlignment(Pos.CENTER);
        
        // Company Logo and Brand Section
        HBox brandSection = new HBox(20);
        brandSection.setAlignment(Pos.CENTER);
        
        // Core2Web Logo
        try {
            Image logoImage = new Image("https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-07-22%20at%2023.02.02_3291e2f4.jpg-TNECC8enbj3DDTBdSdmYdTusqIE9CE.jpeg");
            ImageView logoView = new ImageView(logoImage);
            logoView.setFitWidth(80);
            logoView.setFitHeight(80);
            logoView.setPreserveRatio(true);
            logoView.setSmooth(true);
            
            VBox brandInfo = new VBox(5);
            brandInfo.setAlignment(Pos.CENTER_LEFT);
            
            Label companyName = new Label("Core2Web");
            companyName.setStyle("-fx-text-fill: white; -fx-font-size: 28px; -fx-font-weight: bold;");
            
            Label tagline = new Label("Simulon");
            tagline.setStyle("-fx-text-fill: rgba(255, 255, 255, 0.8); -fx-font-size: 16px;");
            
            brandInfo.getChildren().addAll(companyName, tagline);
            brandSection.getChildren().addAll(logoView, brandInfo);
            
        } catch (Exception e) {
            Label fallbackLogo = new Label("Core2Web");
            fallbackLogo.setStyle("-fx-text-fill: white; -fx-font-size: 32px; -fx-font-weight: bold;");
            brandSection.getChildren().add(fallbackLogo);
        }
        
        // Navigation bar
        HBox navBar = new HBox(30);
        navBar.setAlignment(Pos.CENTER);
        
        
        // Main title
        Label titleLabel = new Label("About Our Physics Simulation Engine");
        titleLabel.setStyle("-fx-text-fill: white; -fx-font-size: 42px; -fx-font-weight: bold; -fx-text-alignment: center;");
        titleLabel.setWrapText(true);
        titleLabel.setTextAlignment(TextAlignment.CENTER);
        
        Label subtitleLabel = new Label("Revolutionizing Physics Education Through Interactive Simulations");
        subtitleLabel.setStyle("-fx-text-fill: rgba(255, 255, 255, 0.9); -fx-font-size: 18px; -fx-text-alignment: center;");
        subtitleLabel.setWrapText(true);
        subtitleLabel.setTextAlignment(TextAlignment.CENTER);
        
        header.getChildren().addAll(brandSection, navBar, titleLabel, subtitleLabel);
        return header;
    }
    
    private Button createNavButton(String text) {
        Button button = new Button(text);
        button.setStyle("-fx-background-color: rgba(255, 255, 255, 0.1); " +
                       "-fx-text-fill: white; " +
                       "-fx-font-size: 14px; " +
                       "-fx-font-weight: bold; " +
                       "-fx-background-radius: 20; " +
                       "-fx-padding: 10 20 10 20; " +
                       "-fx-cursor: hand;");
        
        button.setOnMouseEntered(e -> {
            button.setStyle(button.getStyle().replace("rgba(255, 255, 255, 0.1)", "rgba(255, 255, 255, 0.2)"));
        });
        
        button.setOnMouseExited(e -> {
            if (!text.equals("About Us")) {
                button.setStyle(button.getStyle().replace("rgba(255, 255, 255, 0.2)", "rgba(255, 255, 255, 0.1)"));
            }
        });
        
        return button;
    }
    
    private VBox createMainContent() {
        VBox mainContent = new VBox(40);
        mainContent.setPadding(new Insets(40, 80, 40, 80));
        mainContent.setAlignment(Pos.CENTER);
        
        // Founder Section - NEW SECTION
        VBox founderSection = createFounderSection();
        
        // Mission Section
        // VBox missionSection = createSection(
        //     "Our Mission",
        //     "At Core2Web, we are dedicated to transforming physics education through cutting-edge simulation technology. " +
        //     "Our platform provides students, educators, and researchers with powerful tools to visualize, " +
        //     "understand, and experiment with complex physics concepts in an interactive environment."
        // );
        
        // Vision Section
        // VBox visionSection = createSection(
        //     "Our Vision",
        //     "To become the leading platform for physics simulation and education, making complex scientific " +
        //     "concepts accessible to learners worldwide. We envision a future where every student can " +
        //     "experience the beauty and wonder of physics through immersive, hands-on simulations."
        // );
        
        // Features Grid
        VBox featuresSection = new VBox(20);
        featuresSection.setAlignment(Pos.CENTER);
        
        Label featuresTitle = new Label("What We Offer");
        featuresTitle.setStyle("-fx-text-fill: white; -fx-font-size: 32px; -fx-font-weight: bold;");
        
        HBox featuresRow1 = new HBox(30);
        featuresRow1.setAlignment(Pos.CENTER);
        
        VBox feature1 = createFeatureCard("🔬", "Interactive Simulations", 
            "Real-time physics simulations covering mechanics, thermodynamics, electromagnetism, and quantum physics.");
        
        VBox feature2 = createFeatureCard("📚", "Educational Resources", 
            "Comprehensive learning materials, tutorials, and guided experiments for all skill levels.");
        
        VBox feature3 = createFeatureCard("🎯", "Adaptive Learning", 
            "Personalized learning paths that adapt to individual progress and learning styles.");
        
        featuresRow1.getChildren().addAll(feature1, feature2, feature3);
        
        HBox featuresRow2 = new HBox(30);
        featuresRow2.setAlignment(Pos.CENTER);
        
        VBox feature4 = createFeatureCard("👥", "Community Platform", 
            "Connect with fellow learners, share experiments, and collaborate on physics projects.");
        
        VBox feature5 = createFeatureCard("📊", "Progress Tracking", 
            "Detailed analytics and progress tracking to monitor learning achievements and areas for improvement.");
        
        VBox feature6 = createFeatureCard("🏆", "Gamification", 
            "Engaging quizzes, challenges, and achievements to make learning physics fun and rewarding.");
        
        featuresRow2.getChildren().addAll(feature4, feature5, feature6);
        
        featuresSection.getChildren().addAll(featuresTitle, featuresRow1, featuresRow2);
        
        // Team Section with Real Photos
        VBox teamSection = createTeamSectionWithPhotos();
        
        // Technology Section
        VBox techSection = createSection(
            "Our Technology",
            "Built with modern technologies including JavaFX for desktop applications, advanced physics engines " +
            "for accurate simulations, and cloud-based infrastructure for seamless collaboration. Our platform " +
            "supports real-time rendering, multi-user environments, and cross-platform compatibility."
        );
        
        // Values Section
        //VBox valuesSection = createValuesSection();
        
        mainContent.getChildren().addAll(
            founderSection,  // Added founder section first  
            teamSection,
            techSection
        );
        
        return mainContent;
    }
    
    // NEW METHOD: Create Founder Section
    private VBox createFounderSection() {
        VBox founderSection = new VBox(30);
        founderSection.setAlignment(Pos.CENTER);
        founderSection.setPadding(new Insets(30));
        founderSection.setStyle("-fx-background-color: rgba(255, 255, 255, 0.15); " +
                              "-fx-background-radius: 15; " +
                              "-fx-border-radius: 15;");
        
        Label founderTitle = new Label("Our Founder");
        founderTitle.setStyle("-fx-text-fill: white; -fx-font-size: 36px; -fx-font-weight: bold;");
        
        HBox founderContent = new HBox(40);
        founderContent.setAlignment(Pos.CENTER);
        
        // Founder Photo
        VBox photoContainer = new VBox(15);
        photoContainer.setAlignment(Pos.CENTER);
        photoContainer.setPrefWidth(300);
        
        try {
            Image founderImage = new Image("https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-07-22%20at%2023.01.52_83e05e9c.jpg-FhmDKYLFQkA8UsD9Rfr2sPXCM8ak2V.jpeg");
            ImageView photoView = new ImageView(founderImage);
            photoView.setFitWidth(250);
            photoView.setFitHeight(250);
            photoView.setPreserveRatio(true);
            photoView.setSmooth(true);
            
            // Create circular clip for the image
            photoView.setStyle("-fx-background-radius: 125; -fx-border-radius: 125; " +
                             "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.4), 15, 0, 0, 5);");
            
            Label nameLabel = new Label("Shashikant Bagal");
            nameLabel.setStyle("-fx-text-fill: white; -fx-font-size: 24px; -fx-font-weight: bold;");
            
            Label titleLabel = new Label("Founder & CEO");
            titleLabel.setStyle("-fx-text-fill: rgba(255, 255, 255, 0.9); -fx-font-size: 18px;");
            
            photoContainer.getChildren().addAll(photoView, nameLabel, titleLabel);
            
        } catch (Exception e) {
            // Fallback avatar
            Label avatarLabel = new Label("👤");
            avatarLabel.setStyle("-fx-font-size: 72px;");
            
            Label nameLabel = new Label("Shashikant Bagal");
            nameLabel.setStyle("-fx-text-fill: white; -fx-font-size: 24px; -fx-font-weight: bold;");
            
            photoContainer.getChildren().addAll(avatarLabel, nameLabel);
        }
        
        // Founder Bio
        VBox bioContainer = new VBox(20);
        bioContainer.setAlignment(Pos.TOP_LEFT);
        bioContainer.setPrefWidth(600);
        
        Label bioTitle = new Label("Shashikant Bagal (Shashi Sir)");
        bioTitle.setStyle("-fx-text-fill: white; -fx-font-size: 22px; -fx-font-weight: bold;");
        
        TextArea bioText = new TextArea(
            "Shashikant Bagal (Shashi Sir) is a highly accomplished technologist, educator, and entrepreneur. " +
            "His most notable achievement is the establishment of Core2web in January 2017, where he teaches " +
            "students in core programming languages like C, C++, Java, and Python, along with Operating System " +
            "fundamentals. Beyond foundational concepts, he also specializes in modern framework-based development, " +
            "including Flutter for cross-platform apps, React for front-end development, and Spring Boot for " +
            "enterprise Java applications.\n\n" +
            "He further expanded his entrepreneurial journey by co-founding Incubators System Pvt. Ltd. and " +
            "mentoring for multiple startups.\n\n" +
            "Combining strong theoretical knowledge with real-world industry experience, Shashi Sir bridges the " +
            "gap between education and practical application, inspiring countless students and professionals in " +
            "the ever-evolving field of technology."
        );
        
        bioText.setWrapText(true);
        bioText.setEditable(false);
        bioText.setPrefHeight(200);
        bioText.setStyle("-fx-control-inner-background: rgba(255, 255, 255, 0.1); " +
                        "-fx-background-color: transparent; " +
                        "-fx-text-fill: rgba(255, 255, 255, 0.9); " +
                        "-fx-font-size: 14px; " +
                        "-fx-border-color: transparent; " +
                        "-fx-focus-color: transparent; " +
                        "-fx-faint-focus-color: transparent;");
        
        bioContainer.getChildren().addAll(bioTitle, bioText);
        
        founderContent.getChildren().addAll(photoContainer, bioContainer);
        founderSection.getChildren().addAll(founderTitle, founderContent);
        
        return founderSection;
    }
    
    private VBox createSection(String title, String content) {
        VBox section = new VBox(15);
        section.setAlignment(Pos.CENTER);
        section.setPadding(new Insets(20));
        section.setStyle("-fx-background-color: rgba(255, 255, 255, 0.1); " +
                        "-fx-background-radius: 15; " +
                        "-fx-border-radius: 15;");
        
        Label titleLabel = new Label(title);
        titleLabel.setStyle("-fx-text-fill: white; -fx-font-size: 28px; -fx-font-weight: bold;");
        
        Label contentLabel = new Label(content);
        contentLabel.setStyle("-fx-text-fill: rgba(255, 255, 255, 0.9); -fx-font-size: 16px; -fx-text-alignment: center;");
        contentLabel.setWrapText(true);
        contentLabel.setTextAlignment(TextAlignment.CENTER);
        contentLabel.setMaxWidth(800);
        
        section.getChildren().addAll(titleLabel, contentLabel);
        return section;
    }
    
    private VBox createFeatureCard(String icon, String title, String description) {
        VBox card = new VBox(15);
        card.setPadding(new Insets(25));
        card.setPrefWidth(300);
        card.setPrefHeight(200);
        card.setAlignment(Pos.CENTER);
        card.setStyle("-fx-background-color: rgba(255, 255, 255, 0.15); " +
                     "-fx-background-radius: 15; " +
                     "-fx-border-radius: 15; " +
                     "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 10, 0, 0, 5);");
        
        Label iconLabel = new Label(icon);
        iconLabel.setStyle("-fx-font-size: 36px;");
        
        Label titleLabel = new Label(title);
        titleLabel.setStyle("-fx-text-fill: white; -fx-font-size: 18px; -fx-font-weight: bold; -fx-text-alignment: center;");
        titleLabel.setWrapText(true);
        titleLabel.setTextAlignment(TextAlignment.CENTER);
        
        Label descLabel = new Label(description);
        descLabel.setStyle("-fx-text-fill: rgba(255, 255, 255, 0.8); -fx-font-size: 13px; -fx-text-alignment: center;");
        descLabel.setWrapText(true);
        descLabel.setTextAlignment(TextAlignment.CENTER);
        
        // Hover effect
        card.setOnMouseEntered(e -> {
            card.setStyle("-fx-background-color: rgba(255, 255, 255, 0.25); " +
                         "-fx-background-radius: 15; " +
                         "-fx-border-radius: 15; " +
                         "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 15, 0, 0, 8);");
        });
        
        card.setOnMouseExited(e -> {
            card.setStyle("-fx-background-color: rgba(255, 255, 255, 0.15); " +
                         "-fx-background-radius: 15; " +
                         "-fx-border-radius: 15; " +
                         "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 10, 0, 0, 5);");
        });
        
        card.getChildren().addAll(iconLabel, titleLabel, descLabel);
        return card;
    }
    
    private VBox createTeamSectionWithPhotos() {
        VBox teamSection = new VBox(30);
        teamSection.setAlignment(Pos.CENTER);
        teamSection.setPadding(new Insets(30));
        teamSection.setStyle("-fx-background-color: rgba(255, 255, 255, 0.1); " +
                            "-fx-background-radius: 15; " +
                            "-fx-border-radius: 15;");
        
        Label teamTitle = new Label("Meet Our Core2Web Team");
        teamTitle.setStyle("-fx-text-fill: white; -fx-font-size: 32px; -fx-font-weight: bold;");
        
        // First row of team members
        HBox teamRow1 = new HBox(40);
        teamRow1.setAlignment(Pos.CENTER);
        
        VBox member1 = createTeamMemberWithPhoto(
            "/images/janhavi.jpg", 
            "Janhavi Gujar", 
            "UI UX Developer", 
            ""
        );
        
        VBox member2 = createTeamMemberWithPhoto(
            "/images/yash.jpg", 
            "Yash Shinde", 
            "Frontend Developer", 
            ""
        );
        
        teamRow1.getChildren().addAll(member1, member2);
        
        // Second row of team members
        HBox teamRow2 = new HBox(40);
        teamRow2.setAlignment(Pos.CENTER);
        
        VBox member3 = createTeamMemberWithPhoto(
            "/images/deeps.jpg", 
            "Deepankar Rokade", 
            "Team Leader", 
            ""
        );
        
        VBox member4 = createTeamMemberWithPhoto(
            "/images/shubham.jpg", 
            "Shubham Raje", 
            "Simulation Architect", 
            ""
        );
        
        teamRow2.getChildren().addAll(member3, member4);
        
        teamSection.getChildren().addAll(teamTitle, teamRow1, teamRow2);
        return teamSection;
    }
    
    private VBox createTeamMemberWithPhoto(String photoUrl, String name, String role, String description) {
        VBox member = new VBox(15);
        member.setAlignment(Pos.CENTER);
        member.setPrefWidth(300);
        member.setPadding(new Insets(20));
        member.setStyle("-fx-background-color: rgba(255, 255, 255, 0.1); " +
                       "-fx-background-radius: 10; " +
                       "-fx-border-radius: 10;");
        
        // Photo
        try {
            Image memberImage = new Image(photoUrl);
            ImageView photoView = new ImageView(memberImage);
            photoView.setFitWidth(120);
            photoView.setFitHeight(120);
            photoView.setPreserveRatio(true);
            photoView.setSmooth(true);
            
            // Create circular clip for the image
            photoView.setStyle("-fx-background-radius: 60; -fx-border-radius: 60; " +
                              "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 10, 0, 0, 3);");
            
            member.getChildren().add(photoView);
        } catch (Exception e) {
            // Fallback avatar
            Label avatarLabel = new Label("👤");
            avatarLabel.setStyle("-fx-font-size: 48px;");
            member.getChildren().add(avatarLabel);
        }
        
        Label nameLabel = new Label(name);
        nameLabel.setStyle("-fx-text-fill: white; -fx-font-size: 20px; -fx-font-weight: bold; -fx-text-alignment: center;");
        nameLabel.setTextAlignment(TextAlignment.CENTER);
        
        Label roleLabel = new Label(role);
        roleLabel.setStyle("-fx-text-fill: rgba(255, 255, 255, 0.8); -fx-font-size: 14px; -fx-font-weight: bold; -fx-text-alignment: center;");
        roleLabel.setWrapText(true);
        roleLabel.setTextAlignment(TextAlignment.CENTER);
        
        Label descLabel = new Label(description);
        descLabel.setStyle("-fx-text-fill: rgba(255, 255, 255, 0.7); -fx-font-size: 12px; -fx-text-alignment: center;");
        descLabel.setWrapText(true);
        descLabel.setTextAlignment(TextAlignment.CENTER);
        descLabel.setMaxWidth(280);
        
        // Hover effect for member cards
        member.setOnMouseEntered(e -> {
            member.setStyle("-fx-background-color: rgba(255, 255, 255, 0.2); " +
                           "-fx-background-radius: 10; " +
                           "-fx-border-radius: 10; " +
                           "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 15, 0, 0, 5);");
        });
        
        member.setOnMouseExited(e -> {
            member.setStyle("-fx-background-color: rgba(255, 255, 255, 0.1); " +
                           "-fx-background-radius: 10; " +
                           "-fx-border-radius: 10;");
        });
        
        member.getChildren().addAll(nameLabel, roleLabel, descLabel);
        return member;
    }
    
    private VBox createValuesSection() {
        VBox valuesSection = new VBox(20);
        valuesSection.setAlignment(Pos.CENTER);
        valuesSection.setPadding(new Insets(20));
        valuesSection.setStyle("-fx-background-color: rgba(255, 255, 255, 0.1); " +
                              "-fx-background-radius: 15; " +
                              "-fx-border-radius: 15;");
        
        Label valuesTitle = new Label("Our Core Values");
        valuesTitle.setStyle("-fx-text-fill: white; -fx-font-size: 28px; -fx-font-weight: bold;");
        
        HBox valuesRow = new HBox(30);
        valuesRow.setAlignment(Pos.CENTER);
        
        VBox value1 = createValueCard("🎯", "Excellence", "Striving for the highest quality in everything we do");
        VBox value2 = createValueCard("🤝", "Collaboration", "Working together to achieve common goals");
        VBox value3 = createValueCard("💡", "Innovation", "Continuously pushing the boundaries of what's possible");
        VBox value4 = createValueCard("🌟", "Accessibility", "Making physics education available to everyone");
        
        valuesRow.getChildren().addAll(value1, value2, value3, value4);
        valuesSection.getChildren().addAll(valuesTitle, valuesRow);
        
        return valuesSection;
    }
    
    private VBox createValueCard(String icon, String title, String description) {
        VBox card = new VBox(10);
        card.setAlignment(Pos.CENTER);
        card.setPrefWidth(200);
        card.setPadding(new Insets(20));
        
        Label iconLabel = new Label(icon);
        iconLabel.setStyle("-fx-font-size: 32px;");
        
        Label titleLabel = new Label(title);
        titleLabel.setStyle("-fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold;");
        
        Label descLabel = new Label(description);
        descLabel.setStyle("-fx-text-fill: rgba(255, 255, 255, 0.8); -fx-font-size: 12px; -fx-text-alignment: center;");
        descLabel.setWrapText(true);
        descLabel.setTextAlignment(TextAlignment.CENTER);
        
        card.getChildren().addAll(iconLabel, titleLabel, descLabel);
        return card;
    }
    
    // private VBox createFooter() {
    //     VBox footer = new VBox(15);
    //     footer.setPadding(new Insets(10, 50, 20, 50));
    //     footer.setAlignment(Pos.CENTER);
    //     footer.setStyle("-fx-background-color: rgba(0, 0, 0, 0.3);");
        
    //     Label contactTitle = new Label("Get In Touch with Core2Web");
    //     contactTitle.setStyle("-fx-text-fill: white; -fx-font-size: 20px; -fx-font-weight: bold;");
        
    //     HBox contactInfo = new HBox(40);
    //     contactInfo.setAlignment(Pos.CENTER);
        
    //     Label emailLabel = new Label("📧 contact@core2web.com");
    //     emailLabel.setStyle("-fx-text-fill: rgba(255, 255, 255, 0.9); -fx-font-size: 14px;");
        
    //     Label phoneLabel = new Label("📞 +91 98765 43210");
    //     phoneLabel.setStyle("-fx-text-fill: rgba(255, 255, 255, 0.9); -fx-font-size: 14px;");
        
    //     Label addressLabel = new Label("🏢 Tech Park, Innovation Hub, India");
    //     addressLabel.setStyle("-fx-text-fill: rgba(255, 255, 255, 0.9); -fx-font-size: 14px;");
        
    //     contactInfo.getChildren().addAll(emailLabel, phoneLabel, addressLabel);
        
    //     Label copyrightLabel = new Label("© 2024 Core2Web Physics Simulation Engine. All rights reserved.");
    //     copyrightLabel.setStyle("-fx-text-fill: rgba(255, 255, 255, 0.7); -fx-font-size: 12px;");
        
    //     footer.getChildren().addAll(contactTitle, contactInfo, copyrightLabel);
    //     return footer;
    // }
    
    private void addAnimations(VBox mainContent) {
        // Fade in animation for main content
        FadeTransition fadeIn = new FadeTransition(Duration.millis(1000), mainContent);
        fadeIn.setFromValue(0.0);
        fadeIn.setToValue(1.0);
        
        // Slide up animation
        TranslateTransition slideUp = new TranslateTransition(Duration.millis(800), mainContent);
        slideUp.setFromY(50);
        slideUp.setToY(0);
        
        fadeIn.play();
        slideUp.play();
    }
    
    private String getCustomCSS() {
        return """
            .scroll-pane {
                -fx-background-color: transparent;
            }
            .scroll-pane .viewport {
                -fx-background-color: transparent;
            }
            .scroll-pane .content {
                -fx-background-color: transparent;
            }
            .scroll-bar:vertical {
                -fx-background-color: rgba(255, 255, 255, 0.1);
                -fx-background-radius: 10;
            }
            .scroll-bar:vertical .track {
                -fx-background-color: rgba(255, 255, 255, 0.1);
                -fx-background-radius: 10;
            }
            .scroll-bar:vertical .thumb {
                -fx-background-color: rgba(255, 255, 255, 0.3);
                -fx-background-radius: 10;
            }
            .text-area {
                -fx-background-color: transparent;
            }
            .text-area .content {
                -fx-background-color: rgba(255, 255, 255, 0.1);
                -fx-background-radius: 5;
            }
            .text-area:focused .content {
                -fx-background-color: rgba(255, 255, 255, 0.15);
            }
            .text-area .scroll-pane {
                -fx-background-color: transparent;
            }
            .text-area .scroll-pane .viewport {
                -fx-background-color: transparent;
            }
            .text-area .scroll-pane .content {
                -fx-background-color: transparent;
            }
            """;
    }
    
}