package com.engine.view.pendulum;

import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.text.*;

import com.engine.view.HomePage;

import javafx.animation.*;

public class SimulationPendulum{
    private SimplePendulumSimulation runningSimulation;

    private boolean simulationRunning = false;
    private Timeline simulationTimeline;

    public Scene createPendulumSimWindow() {
        
        // --- White simulation Canvas ---
        Canvas simulationCanvas = new Canvas(400, 400); // Set preferred size
        simulationCanvas.setStyle("-fx-background-color: white; -fx-border-radius: 11; -fx-background-radius: 11;");  
        GraphicsContext gc = simulationCanvas.getGraphicsContext2D(); 

        Text simName = new Text("Simulation Engine");
        simName.setFont(Font.font("Segoe UI", FontWeight.BOLD, 28));
        simName.setFill(Color.WHITE);
       
        Text status = new Text("Status: Ready");
        status.setFont(Font.font("Segoe UI", 16));
        status.setFill(Color.LIGHTGRAY);

        Slider lengthSlider = new Slider(50, 300, 100);
        Label lengthLabel = new Label();
        lengthLabel.setStyle("-fx-text-fill : white;"+
                         "-fx-font-weight: Bold;"+
                         "-fx-font-size : 14px");

        lengthLabel.setText("Length of Rod:\n" + (int) lengthSlider.getValue() + "m/s");
            lengthSlider.valueProperty().addListener((obs, oldV, newV) ->
            lengthLabel.setText("Length of Rod:\n" + newV.intValue() + "m/s")
        );

        Slider angleSlider = new Slider(20,80,45);
        Label AngleLabel = new Label();
        AngleLabel.setStyle("-fx-text-fill : white;"+
                         "-fx-font-weight: Bold;"+
                         "-fx-font-size : 14px");

        AngleLabel.setText("Set Angle:\n" + (int) angleSlider.getValue() + "°");
            angleSlider.valueProperty().addListener((obs, oldV, newV) ->
            AngleLabel.setText("Set Angle:\n" + newV.intValue() + "°")
        );

        
      
        Button startButton = new Button("Start Simulation");
        startButton.setStyle("-fx-background-color: linear-gradient(to right, #43cea2,#185a9d); -fx-text-fill: white; -fx-cursor: thumb;");
        startButton.setAlignment(Pos.BOTTOM_CENTER);
        startButton.setOnAction(e -> { 
            runningSimulation = new SimplePendulumSimulation(lengthSlider.getValue(), angleSlider.getValue(), gc, simulationCanvas);
            //runningSimulation = sim;
            runningSimulation.start();
        });

        Button shareButton = new Button("Exit Simulation");
        shareButton.setStyle("-fx-background-color: linear-gradient(to right, #43cea2,#185a9d); -fx-text-fill: white; -fx-cursor: thumb;");
        shareButton.setAlignment(Pos.BOTTOM_CENTER);
        shareButton.setOnAction(e -> HomePage.homePageStage.setScene(HomePage.homePageScene));

        Button favButton = new Button("Favourite Simulation");
        favButton.setStyle("-fx-background-color: linear-gradient(to right, #43cea2,#185a9d); -fx-text-fill: white; -fx-cursor: thumb;");
        favButton.setAlignment(Pos.BOTTOM_CENTER);
        favButton.setOnAction(e -> toggleSimulation(null, favButton));

        Button stopButton = new Button("Stop Simulation");
        stopButton.setStyle("-fx-background-color: linear-gradient(to right, #43cea2,#185a9d); -fx-text-fill: white; -fx-cursor: thumb;");
        stopButton.setAlignment(Pos.BOTTOM_CENTER);
        stopButton.setOnAction(e -> {
            if (runningSimulation != null) {
                runningSimulation.stop(); // This will stop the AnimationTimer
            }
            status.setText("Status: Stopped");
        });


        HBox controls = new HBox(14, startButton,shareButton,favButton,stopButton);
        controls.setAlignment(Pos.BOTTOM_CENTER);
        controls.setPadding(new Insets(35));
        controls.setStyle(
            "-fx-background-radius: 18; " +
            "-fx-background-color: rgba(30,30,45,0.87);" +
            "-fx-effect: dropshadow(gaussian, #185a9d88, 10,0.7,0,4);"
        );
                        
        

        Slider heightSlider = new Slider(100, 400, 273);
        Label HeightLabel = new Label();
        HeightLabel.setStyle("-fx-text-fill : white;"+
                         "-fx-font-weight: Bold;"+
                         "-fx-font-size : 14px");

        HeightLabel.setText("From Height: " + (int) heightSlider.getValue() + "px");
            heightSlider.valueProperty().addListener((obs, oldV, newV) ->
            HeightLabel.setText("From Height: " + newV.intValue() + "px")
        );

        VBox parameter = new VBox(14,lengthLabel,lengthSlider,AngleLabel,angleSlider);
        parameter.setAlignment(Pos.TOP_LEFT);
        parameter.setMinWidth(100); 
        parameter.setPrefHeight(750);
        parameter.setPadding(new Insets(40));
        parameter.setBackground(new Background(new BackgroundFill(
                                new LinearGradient(0,0,1,1,true, CycleMethod.NO_CYCLE,
                                new Stop(0, Color.web("#8357a4ff")), new Stop(1, Color.web("#18081fff"))),
                                new CornerRadii(25), 
                                Insets.EMPTY
                                )));

        ResultBar resultBar = new ResultBar();
        // resultBar.setRange(simFinalRange);
        // resultBar.setPeriod(simFinalPeriod);
        // resultBar.setHeight(simFinalHeight);

        // Optionally, VBox to control vertical alignment and padding
        VBox canvasHolder = new VBox(simulationCanvas);
        canvasHolder.setAlignment(Pos.CENTER);
        canvasHolder.setPadding(new Insets(30, 0, 30, 0)); // top/right/bottom/left
        canvasHolder.setStyle("-fx-background-color: transparent;");

        Region spacer1 = new Region();
        HBox.setHgrow(spacer1, Priority.ALWAYS);

        VBox results = new VBox(14,spacer1,resultBar);
        results.setAlignment(Pos.TOP_LEFT);
        results.setPadding(new Insets(40));
        parameter.setBackground(new Background(new BackgroundFill(
                                new LinearGradient(0,0,1,1,true, CycleMethod.NO_CYCLE,
                                new Stop(0, Color.web("#1b0a24ff")), new Stop(1, Color.web("#741e94ff"))),
                                new CornerRadii(25), 
                                Insets.EMPTY
                                )));

        Region spacer2 = new Region();
        HBox.setHgrow(spacer2, Priority.ALWAYS);

        HBox Base = new HBox(10,parameter,new VBox(simulationCanvas),results);
        Base.setAlignment(Pos.CENTER_LEFT);

        VBox root = new VBox(25,Base, controls);
        root.setAlignment(Pos.BOTTOM_CENTER);
        root.setPadding(new Insets(40));
        root.setBackground(new Background(new BackgroundFill(
                           new LinearGradient(0,0,1,1,true, CycleMethod.NO_CYCLE,
                           new Stop(0, Color.web("#463d58ff")), new Stop(1, Color.web("#0b030fff"))),
                           CornerRadii.EMPTY, Insets.EMPTY)));
        //root.getChildren().add(Base);
   
        Scene scene = new Scene(root, 1048, 665);
        return scene;
    }

    private void toggleSimulation(Text status, Button shareButton) {
        if (!simulationRunning) {
            status.setText("Status: Running...");
            shareButton.setText("Stop Simulation");
            startSimulationAnimation(status);
        } else {
            status.setText("Status: Ready");
            shareButton.setText("Run Simulation");
            if (simulationTimeline != null) simulationTimeline.stop();
        }
        simulationRunning = !simulationRunning;
    }

    private void startSimulationAnimation(Text status) {
        simulationTimeline = new Timeline(
            new KeyFrame(javafx.util.Duration.seconds(1), evt -> {
                String txt = status.getText();
                int count = txt.matches(".*\\d+") ? Integer.parseInt(txt.replaceAll("\\D+","")) : 0;
                status.setText("Status: Running... Step " + (count + 1));
            })
        );
        simulationTimeline.setCycleCount(Animation.INDEFINITE);
        simulationTimeline.play();
    }
    public void step() {  
    }
}