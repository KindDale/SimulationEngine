package com.engine.view.nocode;

import com.engine.view.UIEffects;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class QuizSection extends Application {

    private final Quiz[] quizSet = new Quiz[]{
            new Quiz("Which planet is known as the Red Planet?", new String[]{"Mercury", "Venus", "Earth", "Mars"}, "Mars"),
            new Quiz("Which gas do plants absorb?", new String[]{"Oxygen", "Nitrogen", "Carbon Dioxide", "Helium"}, "Carbon Dioxide"),
            new Quiz("Fastest land animal?", new String[]{"Lion", "Cheetah", "Horse", "Elephant"}, "Cheetah"),
            new Quiz("Largest ocean on Earth?", new String[]{"Atlantic", "Indian", "Pacific", "Arctic"}, "Pacific"),
            new Quiz("Which language runs in a web browser?", new String[]{"Python", "C++", "Java", "JavaScript"}, "JavaScript"),
    };

    private int currentQuestionIndex = 0;
    private int score = 0;
    private final Button[] optionButtons = new Button[4];
    private final Label questionText = new Label();
    private final Label scoreLabel = new Label("Score: 0");

    @Override
    public void start(Stage primaryStage) {
        
        BorderPane root = new BorderPane();
        Image bgImage = new Image(getClass().getResource("/images/background/bgImage.jpeg").toExternalForm());
        BackgroundImage backgroundImage = new BackgroundImage(
            bgImage,
            BackgroundRepeat.NO_REPEAT,
            BackgroundRepeat.NO_REPEAT,
            BackgroundPosition.DEFAULT,
            new BackgroundSize(100, 100, true, true, true, false)
        );
        root.setBackground(new Background(backgroundImage));

        // LEFT: Sidebar
        VBox leftPanel = new VBox(15);
        leftPanel.setAlignment(Pos.TOP_CENTER);
        leftPanel.setPadding(new Insets(20));
        leftPanel.setPrefWidth(250);
        leftPanel.setStyle("-fx-background-color: rgba(0, 0, 0, 0.3); -fx-background-radius: 10;");
        leftPanel.setAlignment(Pos.CENTER);

        for (int i = 0; i < quizSet.length; i++) {
            Button qButton = new Button(String.format("%02d  Question", i + 1));
            UIEffects.applyButtonHoverEffect(qButton);
            qButton.setMaxWidth(Double.MAX_VALUE);
            qButton.setStyle("-fx-background-color: #ffffff44; -fx-text-fill: white; -fx-font-size: 13px; -fx-background-radius: 8;");
            leftPanel.getChildren().add(qButton);
        }

        // CENTER: Question and Options
        VBox centerPanel = new VBox(20);
        centerPanel.setAlignment(Pos.CENTER);
        centerPanel.setPadding(new Insets(40));
        centerPanel.setAlignment(Pos.CENTER);

        questionText.setFont(new Font("Arial", 20));
        questionText.setTextFill(Color.WHITE);
        questionText.setWrapText(true);

        VBox optionsBox = new VBox(10);
        optionsBox.setAlignment(Pos.CENTER);

        for (int i = 0; i < 4; i++) {
            Button btn = new Button();
            UIEffects.applyButtonHoverEffect(btn);
            btn.setFont(Font.font(14));
            btn.setMaxWidth(400);
            btn.setMinHeight(40);
            btn.setTextFill(Color.WHITE);
            btn.setStyle("-fx-background-color: rgba(255,255,255,0.2); -fx-background-radius: 10;");
            btn.setOnAction(e -> handleAnswer(btn.getText()));
            optionButtons[i] = btn;
            optionsBox.getChildren().add(btn);
        }

        scoreLabel.setFont(Font.font(16));
        scoreLabel.setTextFill(Color.WHITE);

        centerPanel.getChildren().addAll(questionText, optionsBox, scoreLabel);

        // Layout
        root.setLeft(leftPanel);
        root.setCenter(centerPanel);

        loadQuestion();

        Scene scene = new Scene(root, 1048, 700);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Quiz App");
        primaryStage.show();
    }

    private void loadQuestion() {
        Quiz q = quizSet[currentQuestionIndex];
        questionText.setText(q.question);
        for (int i = 0; i < 4; i++) {
            optionButtons[i].setText(q.options[i]);
            optionButtons[i].setDisable(false);
            optionButtons[i].setStyle("-fx-background-color: rgba(255,255,255,0.2); -fx-text-fill: white; -fx-font-size: 14px; -fx-background-radius: 10;");
        }
    }

    private void handleAnswer(String selectedOption) {
        Quiz q = quizSet[currentQuestionIndex];
        boolean isCorrect = selectedOption.equals(q.correctAnswer);
        if (isCorrect) score++;

        for (Button btn : optionButtons) {
            btn.setDisable(true);
            if (btn.getText().equals(q.correctAnswer)) {
                btn.setStyle("-fx-background-color: #00C853; -fx-text-fill: white; -fx-background-radius: 10;");
            } else if (btn.getText().equals(selectedOption)) {
                btn.setStyle("-fx-background-color: #D50000; -fx-text-fill: white; -fx-background-radius: 10;");
            }
        }

        scoreLabel.setText("Score: " + score);

        currentQuestionIndex++;
        if (currentQuestionIndex < quizSet.length) {
            new Thread(() -> {
                try { Thread.sleep(1200); } catch (InterruptedException ignored) {}
                javafx.application.Platform.runLater(this::loadQuestion);
            }).start();
        }
    }

    static class Quiz {
        String question;
        String[] options;
        String correctAnswer;

        public Quiz(String question, String[] options, String correctAnswer) {
            this.question = question;
            this.options = options;
            this.correctAnswer = correctAnswer;
        }
    }

    public Scene createQuizScene() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'createQuizScene'");
    }
}
