package com.engine.view;

import javafx.animation.FadeTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.text.TextAlignment;
import javafx.util.Duration;
import org.json.JSONObject;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.CompletableFuture;

public class AIChatbot {

    private static final String GEMINI_API_KEY = "AIzaSyCDGYmEcQJ5nmnkH9E_ekz87SsEw3Asl5Q";
    private static final String GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" + GEMINI_API_KEY;

    private VBox chatContainer;
    private TextField messageInput;
    private ScrollPane chatScrollPane;
    private HttpClient httpClient;
    private Button sendBtn;
    private boolean isSending = false;

    public static class ChatMessage {
        private final String message;
        private final boolean isUser;
        private final String timestamp;

        public ChatMessage(String message, boolean isUser) {
            this.message = message;
            this.isUser = isUser;
            this.timestamp = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"));
        }

        public String getMessage() { return message; }
        public boolean isUser() { return isUser; }
        public String getTimestamp() { return timestamp; }
    }

    public Scene createChatbotScene(Runnable back) {
        httpClient = HttpClient.newHttpClient();

        BorderPane root = new BorderPane();

        Image backgroundImage = new Image("https://hebbkx1anhila5yf.public.blob.vercel-storage.com/bgImage.jpeg.jpg-fbU7I2tYiA8m0mOWvdQ5KypDCcCT0S.png");
        BackgroundImage bgImage = new BackgroundImage(
            backgroundImage,
            BackgroundRepeat.NO_REPEAT,
            BackgroundRepeat.NO_REPEAT,
            BackgroundPosition.CENTER,
            new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, true)
        );
        root.setBackground(new Background(bgImage));

        VBox header = createHeader(back);
        root.setTop(header);

        VBox chatArea = createChatArea();
        root.setCenter(chatArea);

        HBox inputArea = createInputArea();
        root.setBottom(inputArea);

        Scene scene = new Scene(root, 999, 665);
        // scene.getStylesheets().add("data:text/css," + getCustomCSS());

        addWelcomeMessage();
        messageInput.requestFocus();
        testAPIConnection();

        return scene;
    }

    private VBox createHeader(Runnable back) {
        VBox header = new VBox(15);
        header.setPadding(new Insets(20, 30, 15, 30));
        header.setStyle("-fx-background-color: rgba(255, 255, 255, 0.1); " +
                        "-fx-border-color: rgba(255, 255, 255, 0.2); " +
                        "-fx-border-width: 0 0 1 0;");

        HBox topBar = new HBox(20);
        topBar.setAlignment(Pos.CENTER_LEFT);

        Button backBtn = new Button("← Back");
        backBtn.setStyle("-fx-background-color: linear-gradient(to right, #38b6ff, #7b2ff7);" +
                         "-fx-text-fill: white; " +
                         "-fx-font-size: 14px; " +
                         "-fx-font-weight: bold; " +
                         "-fx-background-radius: 20; " +
                         "-fx-padding: 8 16 8 16; " +
                         "-fx-cursor: hand;");
        
        backBtn.setOnAction(e -> back.run());

        HBox botInfo = new HBox(15);
        botInfo.setAlignment(Pos.CENTER_LEFT);

        Label botAvatar = new Label("🤖");
        botAvatar.setStyle("-fx-font-size: 32px; " +
                           "-fx-background-color: rgba(255, 255, 255, 0.2); " +
                           "-fx-background-radius: 25; " +
                           "-fx-padding: 10;");

        VBox botDetails = new VBox(3);
        botDetails.setAlignment(Pos.CENTER_LEFT);

        Label botName = new Label("Physics AI Assistant");
        botName.setStyle("-fx-text-fill: white; -fx-font-size: 20px; -fx-font-weight: bold;");

        Label botStatus = new Label("⚡ Powered by Gemini 1.5 Flash");
        botStatus.setStyle("-fx-text-fill: rgba(255, 255, 255, 0.8); -fx-font-size: 12px;");

        botDetails.getChildren().addAll(botName, botStatus);
        botInfo.getChildren().addAll(botAvatar, botDetails);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        topBar.getChildren().addAll(backBtn, botInfo, spacer);
        header.getChildren().add(topBar);
        return header;
    }

    private VBox createChatArea() {
        VBox chatArea = new VBox();
        chatArea.setPadding(new Insets(20));

        chatContainer = new VBox(15);
        chatContainer.setPadding(new Insets(10));

        chatScrollPane = new ScrollPane(chatContainer);
        chatScrollPane.setStyle("-fx-background: transparent; -fx-background-color: transparent;");
        chatScrollPane.setFitToWidth(true);
        chatScrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        chatScrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        chatScrollPane.setPrefHeight(400);

        chatArea.getChildren().add(chatScrollPane);
        VBox.setVgrow(chatScrollPane, Priority.ALWAYS);
        return chatArea;
    }

    private HBox createInputArea() {
        HBox inputArea = new HBox(15);
        inputArea.setPadding(new Insets(20, 30, 25, 30));
        inputArea.setAlignment(Pos.CENTER);
        inputArea.setStyle("-fx-background-color: rgba(255, 255, 255, 0.1); " +
                           "-fx-border-color: rgba(255, 255, 255, 0.2); " +
                           "-fx-border-width: 1 0 0 0;");

        messageInput = new TextField();
        messageInput.setPromptText("Ask me anything about physics...");
        messageInput.setPrefHeight(45);
        messageInput.setStyle("-fx-background-color: rgba(255, 255, 255, 0.2); " +
                              "-fx-text-fill: white; " +
                              "-fx-prompt-text-fill: rgba(255, 255, 255, 0.6); " +
                              "-fx-background-radius: 25; " +
                              "-fx-padding: 0 20 0 20; " +
                              "-fx-font-size: 14px;");

        sendBtn = new Button("Send");
        sendBtn.setPrefHeight(45);
        sendBtn.setPrefWidth(80);
        sendBtn.setStyle("-fx-background-color: rgba(255, 255, 255, 0.3); " +
                         "-fx-text-fill: white; " +
                         "-fx-font-size: 14px; " +
                         "-fx-font-weight: bold; " +
                         "-fx-background-radius: 25; " +
                         "-fx-cursor: hand;");

        sendBtn.setOnAction(e -> sendMessage());
        messageInput.setOnAction(e -> sendMessage());

        HBox.setHgrow(messageInput, Priority.ALWAYS);
        inputArea.getChildren().addAll(messageInput, sendBtn);
        return inputArea;
    }

    private void addWelcomeMessage() {
        String welcomeText = "Hello! I'm your Physics AI Assistant powered by Gemini. I can help you with:\n\n" +
                             "• Explaining complex physics concepts\n" +
                             "• Solving physics problems step-by-step\n" +
                             "• Providing formulas and their derivations\n\n" +
                             "Ask me anything about physics!";
        ChatMessage welcomeMessage = new ChatMessage(welcomeText, false);
        addMessageToChat(welcomeMessage);
    }

    private void testAPIConnection() {
        ChatMessage testMessage = new ChatMessage("🔍 Testing Gemini API connection...", false);
        addMessageToChat(testMessage);

        sendToGeminiAI("Hello, please respond with 'API test successful'").thenAccept(response -> {
            javafx.application.Platform.runLater(() -> {
                if (response.toLowerCase().contains("successful")) {
                    ChatMessage successMessage = new ChatMessage("✅ API Connection Successful! Ready to assist.", false);
                    addMessageToChat(successMessage);
                } else {
                    ChatMessage resultMessage = new ChatMessage("⚠️ API Test responded, but confirmation not found. Response: " + response, false);
                    addMessageToChat(resultMessage);
                }
            });
        }).exceptionally(throwable -> {
            javafx.application.Platform.runLater(() -> {
                ChatMessage errorMessage = new ChatMessage("❌ API Test Failed: " + throwable.getMessage(), false);
                addMessageToChat(errorMessage);
            });
            return null;
        });
    }

    private void sendMessage() {
        if (isSending) return;

        String message = messageInput.getText().trim();
        if (!message.isEmpty()) {
            setSendingState(true);
            ChatMessage userMessage = new ChatMessage(message, true);
            addMessageToChat(userMessage);
            messageInput.clear();

            VBox typingIndicator = createTypingIndicator();
            chatContainer.getChildren().add(typingIndicator);
            chatScrollPane.setVvalue(1.0);

            sendToGeminiAI(message).thenAccept(response -> {
                javafx.application.Platform.runLater(() -> {
                    chatContainer.getChildren().remove(typingIndicator);
                    ChatMessage botMessage = new ChatMessage(response, false);
                    addMessageToChat(botMessage);
                    setSendingState(false);
                });
            }).exceptionally(throwable -> {
                javafx.application.Platform.runLater(() -> {
                    chatContainer.getChildren().remove(typingIndicator);
                    String errorText = "❌ Error: " + throwable.getMessage();
                    ChatMessage errorMsg = new ChatMessage(errorText, false);
                    addMessageToChat(errorMsg);
                    setSendingState(false);
                });
                return null;
            });
        }
    }

    private CompletableFuture<String> sendToGeminiAI(String userMessage) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                String physicsPrompt = "You are a friendly and expert physics tutor. Provide a clear, accurate, and educational response. Use simple terms and include formulas (like E=mc^2) where helpful. Question: " + userMessage;
                String requestBody = String.format("{\"contents\":[{\"parts\":[{\"text\":\"%s\"}]}]}", escapeJson(physicsPrompt));

                HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(GEMINI_API_URL))
                        .header("Content-Type", "application/json")
                        .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                        .build();

                HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

                if (response.statusCode() == 200) {
                    return extractTextFromResponse(response.body());
                } else {
                    return String.format("❌ HTTP Error %d: Check your API Key and Google Cloud Console permissions. Response: %s", response.statusCode(), response.body());
                }
            } catch (Exception e) {
                e.printStackTrace();
                return "❌ Connection error: " + e.getMessage();
            }
        });
    }

    private String escapeJson(String text) {
        return text.replace("\\", "\\\\")
                   .replace("\"", "\\\"")
                   .replace("\n", "\\n")
                   .replace("\r", "\\r")
                   .replace("\t", "\\t");
    }

    private String extractTextFromResponse(String jsonResponse) {
        try {
            JSONObject json = new JSONObject(jsonResponse);
            return json.getJSONArray("candidates")
                       .getJSONObject(0)
                       .getJSONObject("content")
                       .getJSONArray("parts")
                       .getJSONObject(0)
                       .getString("text");
        } catch (Exception e) {
            System.err.println("JSON parse error: " + e.getMessage());
            return "⚠️ Could not parse the AI's response. The raw response was: " + jsonResponse;
        }
    }

    private VBox createTypingIndicator() {
        HBox bubble = new HBox(8);
        bubble.setAlignment(Pos.CENTER_LEFT);
        bubble.setPadding(new Insets(12, 16, 12, 16));
        bubble.setStyle("-fx-background-color: rgba(255, 255, 255, 0.2); -fx-background-radius: 18 18 18 5;");

        Label typingLabel = new Label("🤖 AI is thinking...");
        typingLabel.setStyle("-fx-text-fill: rgba(255, 255, 255, 0.8); -fx-font-size: 14px; -fx-font-style: italic;");
        
        bubble.getChildren().add(typingLabel);
        
        VBox typingBox = new VBox(bubble);
        typingBox.setPadding(new Insets(5, 10, 5, 10));
        return typingBox;
    }

    private void setSendingState(boolean sending) {
        isSending = sending;
        messageInput.setEditable(!sending);
        sendBtn.setDisable(sending);
        sendBtn.setText(sending ? "..." : "Send");
    }

    private void addMessageToChat(ChatMessage message) {
        VBox messageBox = createMessageBubble(message);
        chatContainer.getChildren().add(messageBox);

        FadeTransition fadeIn = new FadeTransition(Duration.millis(400), messageBox);
        fadeIn.setFromValue(0.0);
        fadeIn.setToValue(1.0);
        fadeIn.play();

        // Ensure the view scrolls down to the new message
        chatScrollPane.layout();
        chatScrollPane.setVvalue(1.0);
    }

    private VBox createMessageBubble(ChatMessage message) {
        VBox messageBox = new VBox(5);
        messageBox.setPadding(new Insets(5, 10, 5, 10));

        HBox bubbleContainer = new HBox();
        bubbleContainer.setAlignment(message.isUser() ? Pos.CENTER_RIGHT : Pos.CENTER_LEFT);

        VBox bubble = new VBox(8);
        bubble.setPadding(new Insets(12, 16, 12, 16));
        bubble.setMaxWidth(600);
        
        String bubbleStyle = message.isUser() ?
            "-fx-background-color: rgba(255, 255, 255, 0.3); -fx-background-radius: 18 18 5 18;" :
            "-fx-background-color: rgba(255, 255, 255, 0.2); -fx-background-radius: 18 18 18 5;";
        bubble.setStyle(bubbleStyle + "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 5, 0, 0, 2);");

        Label messageLabel = new Label(message.getMessage());
        messageLabel.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");
        messageLabel.setWrapText(true);
        messageLabel.setTextAlignment(TextAlignment.LEFT);

        Label timeLabel = new Label(message.getTimestamp());
        timeLabel.setStyle("-fx-text-fill: rgba(255, 255, 255, 0.6); -fx-font-size: 10px;");

        bubble.getChildren().addAll(messageLabel, timeLabel);
        bubbleContainer.getChildren().add(bubble);
        messageBox.getChildren().add(bubbleContainer);
        return messageBox;
    }

    // private String getCustomCSS() {
    //     return """
    //         .scroll-pane { -fx-background-color: transparent; }
    //         .scroll-pane .viewport { -fx-background-color: transparent; }
    //         .scroll-pane .content { -fx-background-color: transparent; }
    //         .scroll-bar:vertical {
    //             -fx-background-color: rgba(255, 255, 255, 0.1);
    //             -fx-background-radius: 5;
    //             -fx-pref-width: 8;
    //         }
    //         .scroll-bar:vertical .track { -fx-background-color: transparent; }
    //         .scroll-bar:vertical .thumb {
    //             -fx-background-color: rgba(255, 255, 255, 0.3);
    //             -fx-background-radius: 5;
    //         }
    //         .text-field:focused {
    //             -fx-background-color: rgba(255, 255, 255, 0.25);
    //             -fx-effect: dropshadow(gaussian, rgba(255,255,255,0.3), 5, 0, 0, 0);
    //         }
    //         """;
    // }
}