package com.engine.view.quiz;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.*;

public class QuizApi {
    
    public static String getQuiz() {
        try {
            URL url = new URL("https://the-trivia-api.com/api/questions?categories=science&limit=10&region=IN&difficulty=easy&tags=physics");

            HttpURLConnection conn = (HttpURLConnection)url.openConnection();
            
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Content-Type", "application/json");
            
            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));

            String line;
            StringBuilder response = new StringBuilder();

            while ((line = br.readLine()) != null) {
                response.append(line);
            }

            String reString = response.toString();
            System.out.println(reString);

            return reString;
        } catch (Exception e) {

        }
        return null;
    }
}
