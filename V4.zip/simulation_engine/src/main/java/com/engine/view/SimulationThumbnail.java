package com.engine.view;

import com.engine.controller.SceneHeader;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class SimulationThumbnail {
    
    public Stage simulationStage;
    public Scene simulationScene;

    public void setSimulationStage(Stage simulationStage) {
        this.simulationStage = simulationStage;
    }

    public Scene SimulationThumbnailPage(ImageView simulationThumbnail , String simulationTitle, 
            String simulationDescription,EventHandler<ActionEvent> onSimThumbnailAction){
        
        Image bgImage = new Image("/images/background/bgImage.jpeg");
        BackgroundImage backgroundImage = new BackgroundImage(
            bgImage,
            BackgroundRepeat.NO_REPEAT,
            BackgroundRepeat.NO_REPEAT,
            BackgroundPosition.DEFAULT,
            new BackgroundSize(100, 100, true, true, true, false)
        );

        StackPane bg = new StackPane();
        bg.setBackground(new Background(backgroundImage));
        
        Text simTitleText = new Text(simulationTitle);
        simTitleText.setFont(new Font(30));
        simTitleText.setFill(Color.WHITE);
        simTitleText.setStyle("-fx-font-weight: bold;");        
        Text simDescriptionText = new Text(simulationDescription);
                                         
        simDescriptionText.setFont(new Font(15));
        simDescriptionText.setStyle("-fx-font-weight: 600;");
        simDescriptionText.setFill(Color.WHITE);

        VBox simVBox = new VBox(10,simTitleText,simDescriptionText);
        simVBox.setAlignment(Pos.CENTER);
        UIEffects.applyElevationEffect(simVBox);

        Button startButton = SceneHeader.createCustomButton("Start Simulation",onSimThumbnailAction);
        startButton.setStyle(
            "-fx-background-color: linear-gradient(to right, #e275f5ff, #9538e6ff);" +
            "-fx-text-fill: white;" +
            "-fx-font-weight: bold;" +
            "-fx-font-size: 14px;" +
            "-fx-padding: 10 20 10 20;" +
            "-fx-background-radius: 30;" +
            "-fx-cursor: hand;"
        );

        Button backButton = new Button("← Back");
        backButton.setStyle(
            "-fx-background-color: linear-gradient(to right, #e275f5ff, #bf00ff);" +
            "-fx-text-fill: white;" +
            "-fx-font-weight: bold;" +
            "-fx-font-size: 14px;" +
            "-fx-padding: 10 20 10 20;" +
            "-fx-background-radius: 30;" +
            "-fx-cursor: hand;"
        );
        
        UIEffects.applyButtonHoverEffect(backButton);
        backButton.setOnAction(event -> {
            Scene scene = HomePage.homePageScene;
            HomePage.homePageStage.setScene(HomePage.homePageScene);
            Loginpage.applyFadeTransition(scene);
        });

        VBox backVB = new VBox(backButton);
        backVB.setAlignment(Pos.TOP_LEFT);
        UIEffects.applyButtonHoverEffect(startButton);
        VBox vb = new VBox(20,backVB,simVBox,startButton);
        vb.setAlignment(Pos.CENTER);        

        HBox hb = new HBox(20,vb,simulationThumbnail);
        hb.setAlignment(Pos.CENTER);
        bg.getChildren().addAll(hb);

        Scene sc = new Scene(bg,999,665);
        return sc;
    }
}
