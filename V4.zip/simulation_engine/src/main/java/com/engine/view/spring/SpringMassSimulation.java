package com.engine.view.spring;

import javafx.animation.AnimationTimer;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class SpringMassSimulation {
    private double mass;         // Mass of the object (kg)
    private double k;            // Spring constant (N/m)
    private double damping;      // Damping coefficient (typically 0.99~0.999)
    private GraphicsContext gc;
    private Canvas canvas;

    // Physics
    private final double gravity = 9.81;
    private final double equilibriumY = 150; // Mount Y position (pixels)
    private final double restLength = 120;   // Unstretched spring (pixels)
    private double y;                        // Mass center Y (pixels)
    private double v = 0;                    // Velocity (pixels/s)

    // Drawing
    private final double springTopX = 350;   // Horizontal anchor (middle)
    private final double massRadius = 25;    // For drawing magnitude

    private AnimationTimer timer;

    public SpringMassSimulation(double mass, double k, double damping, GraphicsContext gc, Canvas canvas) {
        this.mass = mass;
        this.k = k;
        this.damping = damping;
        this.gc = gc;
        this.canvas = canvas;

        // Initial offset for visible motion
        this.y = equilibriumY + restLength + 60;

        timer = new AnimationTimer() {
            private long lastTime = 0;
            @Override
            public void handle(long now) {
                if (lastTime == 0) {
                    lastTime = now;
                    return;
                }
                double dt = (now - lastTime) / 1_000_000_000.0 * 1; // Slightly faster kinetics
                lastTime = now;
                updatePhysics(dt);
                draw();
            }
        };
        draw();
    }

    // Physics update (Hooke + gravity + damping)
    private void updatePhysics(double dt) {
        double stretch = y - (equilibriumY + restLength);
        double force_spring = -k * stretch;
        double force_gravity = mass * gravity;
        double a = (force_spring + force_gravity) / mass;

        v += a * dt;
        v *= damping;
        y += v * dt;
    }

    // Draw a zigzag spring and mass on canvas
    private void draw() {
        gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());

        // Spring mount
        gc.setFill(Color.DIMGRAY);
        gc.fillRect(springTopX - 30, equilibriumY - 20, 60, 20);

        // Zigzag spring
        int coils = 20;
        double amp = 10;
        double topY = equilibriumY;
        double bottomY = y - massRadius;
        double totalLength = bottomY - topY;
        double segment = totalLength / coils;

        gc.setStroke(Color.GRAY);
        gc.setLineWidth(3);

        double prevX = springTopX, prevY = topY;
        for (int i = 1; i <= coils; i++) {
            double currX = springTopX + (i % 2 == 0 ? -amp : amp);
            double currY = topY + segment * i;
            gc.strokeLine(prevX, prevY, currX, currY);
            prevX = currX;
            prevY = currY;
        }
        gc.strokeLine(prevX, prevY, springTopX, bottomY);

        // Mass (circle)
        gc.setFill(Color.CORNFLOWERBLUE);
        gc.setStroke(Color.DARKBLUE);
        gc.setLineWidth(3);
        gc.fillOval(springTopX - massRadius, y - massRadius, massRadius * 2, massRadius * 2);
        gc.strokeOval(springTopX - massRadius, y - massRadius, massRadius * 2, massRadius * 2);
    }

    public void start() {
        v = 0; // Reset velocity on start
        timer.start();
    }

    public void stop() {
        timer.stop();
    }
}
