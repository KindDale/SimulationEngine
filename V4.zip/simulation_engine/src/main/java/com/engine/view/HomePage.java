package com.engine.view;

import java.util.Arrays;

import com.engine.view.explore.exp;
import com.engine.view.profile.ProfilePage;
import com.engine.view.profile.user;
import com.engine.view.quiz.QuizSection;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class HomePage {

    public static Scene homePageScene;
    public Scene headerExpansionScene;
    public static Stage homePageStage; // This is the stage you need to use

    public void setHomePageScene(Scene homePageScene) {
        HomePage.homePageScene = homePageScene;
    }

    public void setHomePageStage(Stage homePageStage) {
        HomePage.homePageStage = homePageStage;
    }

    public Scene createHomePageScene(Runnable back){

        BorderPane Base = new BorderPane();
        Base.setPadding(new Insets(10));

        Image bgImage = new Image(getClass().getResource("/images/background/bgImage.jpeg").toExternalForm());

        BackgroundImage backgroundImage = new BackgroundImage(
            bgImage,
            BackgroundRepeat.NO_REPEAT,
            BackgroundRepeat.NO_REPEAT,
            BackgroundPosition.DEFAULT,
            new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, true)
        );

        StackPane bg = new StackPane();
        bg.setBackground(new Background(backgroundImage));

        ImageView profileIcon = new ImageView(getClass().getResource("/images/male-face-icon-default-profile-image--c3f2c592f9.jpg").toExternalForm());
        profileIcon.setFitWidth(60);
        profileIcon.setFitHeight(60);
        profileIcon.setOnMouseClicked(event -> {
            ProfilePage profileObj = new ProfilePage();
            user currentUser = new user(
        "Deepankr",
        "test@gmail.com",
        Arrays.asList("Projectile Motion", "Simple Pendulum", "Refraction")
            );
            homePageStage.setScene(profileObj.showProfilePopup(currentUser));
        });

        Circle clip = new Circle(30,30,30);
        profileIcon.setClip(clip);

        Font leagueSpartan = Font.loadFont(getClass().getResourceAsStream("/font/LeagueSpartan-Regular.ttf"), 20);

        Text simName = new Text("Simulon");
        simName.setStyle("-fx-fill : white;" +
                         "-fx-font-weight: Bold;" +
                         "-fx-font-size : 40px");

        Text disbtn = new Text("Quiz");
        disbtn.setFont(leagueSpartan);
        disbtn.setStyle("-fx-fill: white;" +
                        "-fx-font-size : 19px");
        disbtn.setOnMouseClicked(event -> {
            QuizSection quizSection = new QuizSection();
            quizSection.start(homePageStage); // Assuming QuizSection has a start method
        });
        disbtn.setOnMouseEntered(e -> {
            disbtn.setStyle("-fx-font-size:20px; -fx-fill:#b673f8; -fx-font-weight:italic;"
                            + "-fx-effect: dropshadow(gaussian, #231538ff, 18, 0.2, 0, 1);"
                            + "-fx-scale-x:1.11; -fx-scale-y:1.11;"
                            + "-fx-underline: true;");
        });
        disbtn.setOnMouseExited(e -> {
            disbtn.setFill(Color.web("#cccccc"));
            disbtn.setEffect(null);
            disbtn.setStyle("-fx-underline: false;"
                            +"-fx-font-size : 19px; -fx-fill: white;");
        });

        Text home = new Text("Home");
        home.setStyle("-fx-fill : white;"+
                      "-fx-font-size : 19px; -fx-underline: true;");
        home.setOnMouseEntered(e -> {
        home.setStyle("-fx-font-size:20px; -fx-fill:#b673f8; -fx-font-weight:italic;"
                      + "-fx-effect: dropshadow(gaussian, #321e4fff, 18, 0.2, 0, 1);"
                      + "-fx-scale-x:1.11; -fx-scale-y:1.11;"
                      +"-fx-underline: true;");
        });
        home.setOnMouseExited(e -> {
        home.setFill(Color.web("#cccccc"));
        home.setEffect(null);
        home.setStyle("-fx-underline: true;"+
                      "-fx-font-size : 19px; -fx-fill: white;");
        });

        Text expbtn = new Text("Explore");
        expbtn.setStyle("-fx-fill : white;"+
                        "-fx-font-size : 19px");

        expbtn.setOnMouseClicked(event -> {
            exp exploreObj = new exp();
            HomePage.homePageStage.setScene(exploreObj.createExplorePage());
        });

        expbtn.setOnMouseEntered(e -> {
        expbtn.setStyle("-fx-font-size:20px; -fx-fill:#b673f8; -fx-font-weight:italic;"
                        + "-fx-effect: dropshadow(gaussian, #321e4fff, 18, 0.2, 0, 1);"
                        + "-fx-scale-x:1.11; -fx-scale-y:1.11;"
                        +"-fx-underline: true;");
        });
        expbtn.setOnMouseExited(e -> {
        expbtn.setFill(Color.web("#cccccc"));
        expbtn.setEffect(null);
        expbtn.setStyle("-fx-underline: false;"
                        + "-fx-font-size : 19px; -fx-fill: white;");
        });

        Text combtn = new Text("Community");
        combtn.setStyle("-fx-fill : white;"
                        +"-fx-font-size : 19px");

        combtn.setOnMouseClicked(event -> {
            CommunityPage communityPage = new CommunityPage(); 
            homePageStage.setScene(communityPage.createCommunityScene());
            System.out.println("Community button clicked.");
        });

        combtn.setOnMouseEntered(e -> {
        combtn.setStyle("-fx-font-size:20px; -fx-fill:#b673f8; -fx-font-weight:italic;"
                        +"-fx-effect: dropshadow(gaussian, #321e4fff, 18, 0.2, 0, 1);"
                        +"-fx-scale-x:1.11; -fx-scale-y:1.11;"
                        +"-fx-underline: true;");
        });
        combtn.setOnMouseExited(e -> {
        combtn.setFill(Color.web("#cccccc"));
        combtn.setEffect(null);
        combtn.setStyle("-fx-underline: false;"
                        + "-fx-font-size : 19px; -fx-fill: white;");
        });

        Text askaibtn = new Text("Ask AI");
        askaibtn.setStyle("-fx-fill : white;"
                        +"-fx-font-size : 19px");

        askaibtn.setOnMouseClicked(event -> {
            if (HomePage.homePageScene == null) {
                HomePage.homePageScene = homePageStage.getScene();
            }

            AIChatbot chatbotPage = new AIChatbot();

            Runnable goBackToHome = () -> {
                homePageStage.setScene(HomePage.homePageScene);
                homePageStage.setTitle("Simulon"); 
            };

            Scene chatbotScene = chatbotPage.createChatbotScene(goBackToHome);

            homePageStage.setScene(chatbotScene);
            homePageStage.setTitle("Simulon"); 
        });

        askaibtn.setOnMouseEntered(e -> {
        askaibtn.setStyle("-fx-font-size:20px; -fx-fill:#b673f8; -fx-font-weight:italic;"
                        +"-fx-effect: dropshadow(gaussian, #321e4fff, 18, 0.2, 0, 1);"
                        +"-fx-scale-x:1.11; -fx-scale-y:1.11;"
                        +"-fx-underline: true;");
        });

        askaibtn.setOnMouseExited(e -> {
        askaibtn.setFill(Color.web("#cccccc"));
        askaibtn.setEffect(null);
        askaibtn.setStyle("-fx-underline: false;"
                        + "-fx-font-size : 19px; -fx-fill: white;");
        });

        Region spacer1 = new Region();
        HBox.setHgrow(spacer1, Priority.ALWAYS);

        HBox Bar1 = new HBox(40);
        Bar1.setAlignment(Pos.CENTER_LEFT);
        Bar1.getChildren().addAll(simName,spacer1,home,combtn,disbtn,expbtn,askaibtn,profileIcon);
        Bar1.setMaxHeight(100);
        Bar1.setPadding(new Insets(10));

        Text headerText = new Text("Bring Physics to Life: Simulate, Explore, Excel");
        headerText.setFont(new Font(20));
        headerText.setStyle("-fx-font-weight: bold; -fx-fill: white;");
        VBox header = new VBox(headerText);
        header.setAlignment(Pos.CENTER);

        HBox Bar2 = new HBox(10);
        Bar2.setAlignment(Pos.CENTER_LEFT);
        Bar2.getChildren().addAll(header);
        Bar2.setPadding(new Insets(10));

        Image icon1Image = new Image("/images/kinematicsSim.png");

        VBox card1 = createSimulationCard("Simple Harmonic Motion","Explore and visualize projectile trajectories in 2D physics. Experiment with angle, velocity, and gravity!","https://user-gen-media-assets.s3.amazonaws.com/gpt4o_images/2fe4021b-6789-4247-9bfe-9c37004e9a48.png", "4.8","2,312",icon1Image);
        UIEffects.styleCard(card1);
        card1.setOnMouseClicked(event -> 
        {    
            Scene mechanicsScene = HeaderExpansion.createMechanicsHeader();
            homePageStage.setScene(mechanicsScene);
            Loginpage.applyFadeTransition(mechanicsScene);
        });

        VBox card2 = createSimulationCard("Kinematics","Explore and visualize projectile trajectories in 2D physics. Experiment with angle, velocity, and gravity!","https://user-gen-media-assets.s3.amazonaws.com/gpt4o_images/2fe4021b-6789-4247-9bfe-9c37004e9a48.png", "4.8","2,312",icon1Image);
        UIEffects.styleCard(card2);
        card2.setOnMouseClicked(event -> {
            Scene projectileScene = HeaderExpansion.createProjectileHeader();
            homePageStage.setScene(projectileScene);
            Loginpage.applyFadeTransition(projectileScene);
        });

        VBox card3 = createSimulationCard("Optics","Explore and visualize projectile trajectories in 2D physics. Experiment with angle, velocity, and gravity!","https://user-gen-media-assets.s3.amazonaws.com/gpt4o_images/2fe4021b-6789-4247-9bfe-9c37004e9a48.png", "4.8","2,312",icon1Image);
        UIEffects.styleCard(card3);
        card3.setOnMouseClicked(event -> {
            Scene springScene = HeaderExpansion.createSpringHeader();
            homePageStage.setScene(springScene);
            Loginpage.applyFadeTransition(springScene);
        });

        VBox card4 = createSimulationCard("Spring Mass Simulation","Explore and visualize projectile trajectories in 2D physics. Experiment with angle, velocity, and gravity!","https://user-gen-media-assets.s3.amazonaws.com/gpt4o_images/2fe4021b-6789-4247-9bfe-9c37004e9a48.png", "4.8","2,312",icon1Image);
        UIEffects.styleCard(card4);
        card4.setOnMouseClicked(event -> {
            Scene pendulumScene = HeaderExpansion.createPendulumHeader();
            homePageStage.setScene(pendulumScene);
            Loginpage.applyFadeTransition(pendulumScene);
        });

        HBox hcard1 = new HBox(50,card1,card2);
        hcard1.setAlignment(Pos.CENTER);

        HBox hcard2 = new HBox(50,card3,card4);
        hcard2.setAlignment(Pos.CENTER);

        VBox plotBox = new VBox(40,hcard1,hcard2);
        plotBox.setPadding(new Insets(50));

        VBox vb = new VBox(5,Bar1,Bar2,plotBox);

        ScrollPane scrollPane = new ScrollPane(vb);
        scrollPane.setFitToWidth(true);
        scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scrollPane.setStyle("-fx-background: transparent; -fx-background-color: transparent;");

        bg.getChildren().add(scrollPane);

        Scene sc = new Scene(bg,999,665);
        return sc;
    }

    public static VBox createSimulationCard(String simName, String description,String simImageUrl,String rating,String runs ,Image icon1Image) {
    VBox card = new VBox(10);
    card.setPadding(new Insets(10));
    card.setPrefWidth(400);
    card.setPrefHeight(200);
    card.setStyle(
        "-fx-background-color: #F9FAFB; " +
        "-fx-background-radius: 14; " +
        "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.08), 8, 0, 0, 4);"
    );

    UIEffects.applyFrostedStyle(card);

    // Static Data
    String simName1 = simName;
    String description1 = description;
    String simImageUrl1 = simImageUrl; 
    String rating1 = rating;
    String runs1 = runs;
    Image backgroundImageUrl1 = icon1Image;

    // Simulation Image
    ImageView simImage1 = new ImageView(new Image(simImageUrl1));
    simImage1.setFitWidth(200);
    simImage1.setFitHeight(100);
    simImage1.setPreserveRatio(true);
    simImage1.setSmooth(true);

    // Simulation Name
    Label nameLabel = new Label(simName1);
    nameLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 15));
    nameLabel.setWrapText(true);

    // Description
    Label descLabel = new Label(description1);
    descLabel.setFont(Font.font("Segoe UI", 11));
    descLabel.setTextFill(Color.web("#555555"));
    descLabel.setWrapText(true);

    // Rating & Runs
    Label statsLabel = new Label("★ " + rating1 + "   ▶️ " + runs1 + " runs");
    statsLabel.setFont(Font.font("Segoe UI", 11));
    statsLabel.setTextFill(Color.web("#6C63FF"));

    Button launchSim = new Button("🚀 Launch");
    launchSim.setStyle("-fx-background-color: #6C63FF; -fx-text-fill: white; -fx-background-radius: 10;");
    launchSim.setPrefWidth(85);

    HBox buttons = new HBox(10, launchSim);
    buttons.setAlignment(Pos.CENTER);

    DropShadow ds = new DropShadow(10, Color.rgb(100, 99, 255, .12));
    card.setEffect(ds);
    card.getChildren().addAll(
        simImage1, nameLabel, descLabel,
        statsLabel, buttons
    );

    BackgroundImage bgImage = new BackgroundImage(
        backgroundImageUrl1,
        BackgroundRepeat.NO_REPEAT,
        BackgroundRepeat.NO_REPEAT,
        BackgroundPosition.DEFAULT,
        new BackgroundSize(
            BackgroundSize.AUTO,
            BackgroundSize.AUTO,
            false,
            false,
            true,
            true
        )
    );

    card.setBackground(new Background(bgImage));
        
    return card;
}
}