package com.engine.view; 

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.paint.CycleMethod;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class CommunityPage { 
    
    private ListView<Community> communityListView;
    private VBox chatArea;
    private TextField messageInput;
    private ScrollPane chatScrollPane;
    private VBox messagesContainer;
    private Community selectedCommunity;
    
    public static class Community {
        private String name;
        private String lastMessage;
        private String timestamp;
        private int unreadCount;
        private int memberCount;
        private boolean isOnline;
        private String avatarText;
        
        public Community(String name, String lastMessage, String timestamp, 
                         int unreadCount, int memberCount, boolean isOnline) {
            this.name = name;
            this.lastMessage = lastMessage;
            this.timestamp = timestamp;
            this.unreadCount = unreadCount;
            this.memberCount = memberCount;
            this.isOnline = isOnline;
            this.avatarText = name.substring(0, Math.min(2, name.length())).toUpperCase();
        }
        
        public String getName() { return name; }
        public String getLastMessage() { return lastMessage; }
        public String getTimestamp() { return timestamp; }
        public int getUnreadCount() { return unreadCount; }
        public int getMemberCount() { return memberCount; }
        public boolean isOnline() { return isOnline; }
        public String getAvatarText() { return avatarText; }
    }
    
    public static class Message {
        private String sender;
        private String content;
        private String timestamp;
        private boolean isOwn;
        
        public Message(String sender, String content, boolean isOwn) {
            this.sender = sender;
            this.content = content;
            this.isOwn = isOwn;
            this.timestamp = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"));
        }
        
        public String getSender() { return sender; }
        public String getContent() { return content; }
        public String getTimestamp() { return timestamp; }
        public boolean isOwn() { return isOwn; }
    }
    
    public Scene createCommunityScene() {
        StackPane root = new StackPane();
        
        LinearGradient gradient = new LinearGradient(
            0, 0, 1, 1, true, CycleMethod.NO_CYCLE,
            new Stop(0, Color.rgb(52, 152, 219)),      
            new Stop(0.5, Color.rgb(155, 89, 182)),    
            new Stop(1, Color.rgb(142, 68, 173))       
        );
        
        Region backgroundRegion = new Region();
        backgroundRegion.setBackground(new Background(new BackgroundFill(gradient, null, null)));
        
        HBox mainContent = createMainContent();
        
        root.getChildren().addAll(backgroundRegion, mainContent);
        
        Scene scene = new Scene(root, 1200, 800);
        scene.getStylesheets().add(getClass().getResource("styles.css") != null ? 
            getClass().getResource("styles.css").toExternalForm() : "");
        
        initializeSampleData(); 
        
        return scene; 
    }
    
    private HBox createMainContent() {
        HBox mainContent = new HBox();
        mainContent.setSpacing(0);
        mainContent.setPadding(new Insets(0));
        
        VBox sidebar = createCommunitySidebar();
        
        chatArea = createChatArea();
        
        mainContent.getChildren().addAll(sidebar, chatArea);
        HBox.setHgrow(chatArea, Priority.ALWAYS);
        
        return mainContent;
    }
    
    private VBox createCommunitySidebar() {
        VBox sidebar = new VBox();
        sidebar.setPrefWidth(350);
        sidebar.setMaxWidth(350);
        sidebar.setMinWidth(350);
        sidebar.setStyle("-fx-background-color: rgba(255, 255, 255, 0.9); " +
                         "-fx-background-radius: 0; " +
                         "-fx-border-color: rgba(255, 255, 255, 0.3); " +
                         "-fx-border-width: 0 1 0 0;");
        
        VBox header = createSidebarHeader();
        
        communityListView = createCommunityList();
        
        sidebar.getChildren().addAll(header, communityListView);
        VBox.setVgrow(communityListView, Priority.ALWAYS);
        
        return sidebar;
    }
    
    private VBox createSidebarHeader() {
        VBox header = new VBox();
        header.setPadding(new Insets(20));
        header.setSpacing(15);
        header.setStyle("-fx-background-color: rgba(255, 255, 255, 0.1); " +
                       "-fx-border-color: rgba(255, 255, 255, 0.2); " +
                       "-fx-border-width: 0 0 1 0;");
        
        HBox titleBox = new HBox();
        titleBox.setAlignment(Pos.CENTER_LEFT);
        titleBox.setSpacing(10);
        
        Label titleLabel = new Label("Communities");
        titleLabel.setFont(Font.font("System", FontWeight.BOLD, 18));
        titleLabel.setTextFill(Color.rgb(60, 60, 60));
        
        Button settingsBtn = new Button("⚙");
        settingsBtn.setStyle("-fx-background-color: transparent; " +
                             "-fx-text-fill: #666; " +
                             "-fx-font-size: 16px; " +
                             "-fx-cursor: hand;");
        
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        
        titleBox.getChildren().addAll(titleLabel, spacer, settingsBtn);
        
        Button backBtn = new Button("⬅ Back");
        backBtn.setStyle("-fx-background-color: #333; -fx-text-fill: white; -fx-padding: 8 20 8 20; -fx-font-weight: bold;");
        backBtn.setOnAction(e -> {HomePage.homePageStage.setScene(HomePage.homePageScene);});

        TextField searchField = new TextField();
        searchField.setPromptText("Search communities...");
        searchField.setStyle("-fx-background-color: rgba(255, 255, 255, 0.7); " +
                             "-fx-background-radius: 20; " +
                             "-fx-border-radius: 20; " +
                             "-fx-padding: 8 15; " +
                             "-fx-font-size: 14px;");
        
        header.getChildren().addAll(backBtn,titleBox,searchField);
        
        return header;
    }
    
    private ListView<Community> createCommunityList() {
        ListView<Community> listView = new ListView<>();
        listView.setStyle("-fx-background-color: transparent; " +
                          "-fx-control-inner-background: transparent;");
        
        listView.setCellFactory(param -> new CommunityListCell());
        
        listView.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                selectedCommunity = newVal;
                updateChatArea();
            }
        });
        
        return listView;
    }
    
    private VBox createChatArea() {
        VBox chatArea = new VBox();
        chatArea.setStyle("-fx-background-color: rgba(255, 255, 255, 0.1);");
        
        HBox chatHeader = createChatHeader();
        
        messagesContainer = new VBox();
        messagesContainer.setSpacing(10);
        messagesContainer.setPadding(new Insets(20));
        
        chatScrollPane = new ScrollPane(messagesContainer);
        chatScrollPane.setStyle("-fx-background-color: transparent; " +
                                  "-fx-control-inner-background: transparent;");
        chatScrollPane.setFitToWidth(true);
        chatScrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        chatScrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        
        HBox messageInputArea = createMessageInputArea();
        
        chatArea.getChildren().addAll(chatHeader, chatScrollPane, messageInputArea);
        VBox.setVgrow(chatScrollPane, Priority.ALWAYS);
        
        return chatArea;
    }
    
    private HBox createChatHeader() {
        HBox header = new HBox();
        header.setPadding(new Insets(15, 20, 15, 20));
        header.setAlignment(Pos.CENTER_LEFT);
        header.setSpacing(15);
        header.setStyle("-fx-background-color: rgba(255, 255, 255, 0.9); " +
                       "-fx-border-color: rgba(255, 255, 255, 0.3); " +
                       "-fx-border-width: 0 0 1 0;");
        
        Circle avatar = new Circle(20);
        avatar.setFill(LinearGradient.valueOf("linear-gradient(to bottom right, #4A90E2, #9B59B6)"));
        
        VBox infoBox = new VBox();
        infoBox.setSpacing(2);
        
        Label nameLabel = new Label("Select a community");
        nameLabel.setFont(Font.font("System", FontWeight.BOLD, 16));
        nameLabel.setTextFill(Color.rgb(60, 60, 60));
        
        Label membersLabel = new Label("Choose from the list");
        membersLabel.setFont(Font.font("System", 12));
        membersLabel.setTextFill(Color.rgb(120, 120, 120));
        
        infoBox.getChildren().addAll(nameLabel, membersLabel);
        
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        
        String buttonStyle = "-fx-background-color: transparent; " +
                             "-fx-text-fill: #666; " +
                             "-fx-font-size: 16px; " +
                             "-fx-cursor: hand; " +
                             "-fx-padding: 8;";
        
        header.getChildren().addAll(avatar, infoBox, spacer);
        
        return header;
    }
    
    private HBox createMessageInputArea() {
        HBox inputArea = new HBox();
        inputArea.setPadding(new Insets(15, 20, 15, 20));
        inputArea.setSpacing(10);
        inputArea.setAlignment(Pos.CENTER);
        inputArea.setStyle("-fx-background-color: rgba(255, 255, 255, 0.9); " +
                           "-fx-border-color: rgba(255, 255, 255, 0.3); " +
                           "-fx-border-width: 1 0 0 0;");
        
        messageInput = new TextField();
        messageInput.setPromptText("Type a message...");
        messageInput.setStyle("-fx-background-color: rgba(255, 255, 255, 0.8); " +
                              "-fx-background-radius: 25; " +
                              "-fx-border-radius: 25; " +
                              "-fx-padding: 10 20; " +
                              "-fx-font-size: 14px;");
        
        Button sendBtn = new Button("Send");
        sendBtn.setStyle("-fx-background-color: linear-gradient(to right, #00ffe7, #00c3ff);" +
            "-fx-text-fill: white;" +
            "-fx-font-weight: bold;" +
            "-fx-font-size: 14px;" +
            "-fx-padding: 10 20 10 20;" +
            "-fx-background-radius: 30;" +
            "-fx-cursor: hand;");
        
        sendBtn.setOnAction(e -> sendMessage());
        messageInput.setOnAction(e -> sendMessage());
        
        HBox.setHgrow(messageInput, Priority.ALWAYS);
        
        inputArea.getChildren().addAll(messageInput, sendBtn);
        
        return inputArea;
    }
    
    private void sendMessage() {
        String text = messageInput.getText().trim();
        if (!text.isEmpty() && selectedCommunity != null) {
            Message message = new Message("You", text, true);
            addMessageToChat(message);
            messageInput.clear();
        }
    }
    
    private void addMessageToChat(Message message) {
        HBox messageBox = new HBox();
        messageBox.setPadding(new Insets(5));
        
        // Always align messages to the left
        messageBox.setAlignment(Pos.CENTER_LEFT);
        
        VBox messageBubble = new VBox();
        messageBubble.setSpacing(2);
        messageBubble.setPadding(new Insets(10, 15, 10, 15));
        messageBubble.setMaxWidth(400);
        
        messageBubble.setStyle("-fx-background-color: rgba(255, 255, 255, 0.9); " +
                               "-fx-background-radius: 15 15 15 5; " +
                               "-fx-text-fill: black;");
        
        Label senderLabel = new Label(message.getSender());
        senderLabel.setFont(Font.font("System", FontWeight.BOLD, 12));
        messageBubble.getChildren().add(senderLabel);
        
        Label contentLabel = new Label(message.getContent());
        contentLabel.setWrapText(true);
        contentLabel.setFont(Font.font("System", 14));
        
        Label timeLabel = new Label(message.getTimestamp());
        timeLabel.setFont(Font.font("System", 10));
        timeLabel.setTextFill(Color.rgb(120, 120, 120));
        
        messageBubble.getChildren().addAll(contentLabel, timeLabel);
        messageBox.getChildren().add(messageBubble);
        
        messagesContainer.getChildren().add(messageBox);
        
        // Auto-scroll to bottom
        chatScrollPane.setVvalue(1.0);
    }
    
    private void updateChatArea() {
        if (selectedCommunity == null) return;
        
        // Update chat header
        HBox header = (HBox) chatArea.getChildren().get(0);
        VBox infoBox = (VBox) header.getChildren().get(1);
        
        Label nameLabel = (Label) infoBox.getChildren().get(0);
        Label membersLabel = (Label) infoBox.getChildren().get(1);
        
        nameLabel.setText(selectedCommunity.getName());
        membersLabel.setText(selectedCommunity.getMemberCount() + " members" + 
                             (selectedCommunity.isOnline() ? " • Online" : ""));
        
        // Clear and add sample messages
        messagesContainer.getChildren().clear();
        addSampleMessages();
    }
    
    private void addSampleMessages() {
        List<Message> sampleMessages = List.of(
            new Message("Alex Chen", "Hey everyone! Just discovered this amazing new React library for animations.", false),
            new Message("You", "Yes! I've been using it for my latest project. The performance improvements are incredible.", true),
            new Message("Sarah Kim", "Could you share some examples? I'm working on a dashboard that could benefit from smooth animations.", false),
            new Message("Mike Johnson", "I have a CodePen with some examples. Let me find the link...", false),
            new Message("You", "That would be awesome! Thanks Mike 🙏", true)
        );
        
        for (Message message : sampleMessages) {
            addMessageToChat(message);
        }
    }
    
    private void initializeSampleData() {
        ObservableList<Community> communities = FXCollections.observableArrayList(
            new Community("Tech Enthusiasts", "Check out this new React framework!", "2:30 PM", 3, 1247, true)
            );
        
        communityListView.setItems(communities);
        
        // Select first community by default
        if (!communities.isEmpty()) {
            communityListView.getSelectionModel().select(0);
        }
    }
    
    // Custom cell for community list (unchanged)
    private class CommunityListCell extends ListCell<Community> {
        @Override
        protected void updateItem(Community community, boolean empty) {
            super.updateItem(community, empty);
            
            if (empty || community == null) {
                setGraphic(null);
                return;
            }
            
            HBox cellBox = new HBox();
            cellBox.setSpacing(12);
            cellBox.setPadding(new Insets(12));
            cellBox.setAlignment(Pos.CENTER_LEFT);
            
            // Avatar
            StackPane avatarPane = new StackPane();
            Circle avatarCircle = new Circle(25);
            avatarCircle.setFill(LinearGradient.valueOf("linear-gradient(to bottom right, #4A90E2, #9B59B6)"));
            
            Label avatarLabel = new Label(community.getAvatarText());
            avatarLabel.setTextFill(Color.WHITE);
            avatarLabel.setFont(Font.font("System", FontWeight.BOLD, 12));
            
            avatarPane.getChildren().addAll(avatarCircle, avatarLabel);
            
            // Online indicator
            if (community.isOnline()) {
                Circle onlineIndicator = new Circle(4);
                onlineIndicator.setFill(Color.rgb(37, 211, 102));
                onlineIndicator.setStroke(Color.WHITE);
                onlineIndicator.setStrokeWidth(2);
                StackPane.setAlignment(onlineIndicator, Pos.BOTTOM_RIGHT);
                avatarPane.getChildren().add(onlineIndicator);
            }
            
            // Content
            VBox contentBox = new VBox();
            contentBox.setSpacing(2);
            
            HBox topRow = new HBox();
            topRow.setAlignment(Pos.CENTER_LEFT);
            topRow.setSpacing(5);
            
            Label nameLabel = new Label(community.getName());
            nameLabel.setFont(Font.font("System", FontWeight.BOLD, 14));
            nameLabel.setTextFill(Color.rgb(60, 60, 60));
            
            Region spacer = new Region();
            HBox.setHgrow(spacer, Priority.ALWAYS);
            
            Label timeLabel = new Label(community.getTimestamp());
            timeLabel.setFont(Font.font("System", 10));
            timeLabel.setTextFill(Color.rgb(120, 120, 120));
            
            topRow.getChildren().addAll(nameLabel, spacer, timeLabel);
            
            HBox bottomRow = new HBox();
            bottomRow.setAlignment(Pos.CENTER_LEFT);
            bottomRow.setSpacing(5);
            
            Label messageLabel = new Label(community.getLastMessage());
            messageLabel.setFont(Font.font("System", 12));
            messageLabel.setTextFill(Color.rgb(100, 100, 100));
            messageLabel.setMaxWidth(200);
            
            Region spacer2 = new Region();
            HBox.setHgrow(spacer2, Priority.ALWAYS);
            
            if (community.getUnreadCount() > 0) {
                Label unreadLabel = new Label(String.valueOf(community.getUnreadCount()));
                unreadLabel.setStyle("-fx-background-color: #25D366; " +
                                     "-fx-text-fill: white; " +
                                     "-fx-background-radius: 10; " +
                                     "-fx-padding: 2 6; " +
                                     "-fx-font-size: 10px; " +
                                     "-fx-font-weight: bold;");
                bottomRow.getChildren().add(unreadLabel);
            }
            
            bottomRow.getChildren().addAll(messageLabel, spacer2);
            
            Label membersLabel = new Label("👥 " + community.getMemberCount() + " members");
            membersLabel.setFont(Font.font("System", 10));
            membersLabel.setTextFill(Color.rgb(120, 120, 120));
            
            contentBox.getChildren().addAll(topRow, bottomRow, membersLabel);
            
            cellBox.getChildren().addAll(avatarPane, contentBox);
            
            // Hover effect
            cellBox.setOnMouseEntered(e -> {
                if (!isSelected()) {
                    cellBox.setStyle("-fx-background-color: rgba(255, 255, 255, 0.3); -fx-background-radius: 8;");
                }
            });
            
            cellBox.setOnMouseExited(e -> {
                if (!isSelected()) {
                    cellBox.setStyle("-fx-background-color: transparent;");
                }
            });
            
            // Selection styling
            if (isSelected()) {
                cellBox.setStyle("-fx-background-color: rgba(37, 211, 102, 0.2); -fx-background-radius: 8;");
            }
            
            setGraphic(cellBox);
        }
    }
}