package com.engine.view.pendulum;

import javafx.animation.AnimationTimer;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class SimplePendulumSimulation {
    private double length;  // length of pendulum arm in pixels (or scaled units)
    private double angle;   // initial angle in degrees
    private double gravity = 9.8;
    private GraphicsContext gc;
    private Canvas canvas;
    private AnimationTimer timer;

    private double angularVelocity = 0;
    private double angularAcceleration = 0;

    public SimplePendulumSimulation(double length, double angleDeg, GraphicsContext gc, Canvas canvas) {
        this.length = length;
        this.angle = Math.toRadians(angleDeg);
        this.gc = gc;
        this.canvas = canvas;
    }

    public void start() {
        timer = new AnimationTimer() {
            private long lastTime = 0;

            @Override
            public void handle(long now) {
                if (lastTime == 0) {
                    lastTime = now;
                    return;
                }
                double dt = ((now - lastTime) / 1_000_000_000.0) * 4;  // convert nanoseconds to seconds
                lastTime = now;

                // Pendulum physics equation: θ'' = -(g / L) * sin(θ)
                angularAcceleration = -(gravity / length) * Math.sin(angle);
                angularVelocity += angularAcceleration * dt;
                angle += angularVelocity * dt;

                // Damping (optional)
                angularVelocity *= 0.999;

                // Clear canvas
                gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());

                // Pivot point
                double pivotX = canvas.getWidth() / 2;
                double pivotY = 50;

                // Bob position
                double bobX = pivotX + length * Math.sin(angle);
                double bobY = pivotY + length * Math.cos(angle);

                // Draw pendulum arm
                gc.setStroke(Color.BLACK);
                gc.setLineWidth(3);
                gc.strokeLine(pivotX, pivotY, bobX, bobY);

                // Draw bob
                gc.setFill(Color.DARKBLUE);
                gc.fillOval(bobX - 15, bobY - 15, 30, 30);
            }
        };
        timer.start();
    }

    public void stop() {
        if (timer != null) {
            timer.stop();
        }
    }
}
