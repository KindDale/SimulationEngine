package com.engine.view;

import com.engine.controller.CreateSimThumbnail;
import com.engine.controller.SceneHeader;

import javafx.scene.Scene;
import javafx.scene.image.ImageView;

public class HeaderExpansion {

    public static Scene createMechanicsHeader() {
 
        CreateSimThumbnail cst = new CreateSimThumbnail();
        ImageView pendulumImage = new ImageView("/images/pendulum/pendulum.jpg");
        pendulumImage.setFitHeight(100);
        pendulumImage.setFitWidth(100);

        SceneHeader sh = new SceneHeader();
        Scene sc = sh.createHeaderScene("Simple Harmonic Motion", 
        "Mechanics is a fundamental branch of physics that studies the motion of objectsand the forces that cause or change this motion.", 
        "Pendulum", pendulumImage,
        "\"Explore and visualize projectile trajectories in 2D physics. Experiment with angle, velocity, and gravity!",
        e ->{
            HomePage.homePageStage.setScene(cst.initializeSimplePendulum());
        });
        
        return sc;
    }

    public static Scene createProjectileHeader(){

        CreateSimThumbnail cst = new CreateSimThumbnail();
        ImageView projectileImage = new ImageView("/images/projectile/projectile.jpg");
        projectileImage.setFitHeight(100);
        projectileImage.setFitWidth(100);

        SceneHeader sh = new SceneHeader();
        Scene sc = sh.createHeaderScene("Kinematics", 
        "Mechanics is a fundamental branch of physics that studies the motion of objectsand the forces that cause or change this motion.", 
        "Projectile Motion", projectileImage ,
        "Explore and visualize projectile trajectories in 2D physics. Experiment with angle, velocity, and gravity!",
        e ->{
            HomePage.homePageStage.setScene(cst.initializeProjectile());
        });
        
        return sc;
    }

    public static Scene createSpringHeader(){

        CreateSimThumbnail cst = new CreateSimThumbnail();
        ImageView springImage = new ImageView("/images/refraction/refraction.jpg");
        springImage.setFitHeight(100);
        springImage.setFitWidth(100);

        SceneHeader sh = new SceneHeader();
        Scene sc = sh.createHeaderScene("Optics", 
        "Mechanics is a fundamental branch of physics that studies the motion of objectsand the forces that cause or change this motion.", 
        "Refraction of Light", springImage,
        "\"Explore and visualize projectile trajectories in 2D physics. Experiment with angle, velocity, and gravity!",
        e ->{
            HomePage.homePageStage.setScene(cst.initializeRefraction());
        });
        return sc;
    }

    public static Scene createPendulumHeader(){

        CreateSimThumbnail cst = new CreateSimThumbnail();

        ImageView springImage = new ImageView("/images/spring/spring.jpg");
        springImage.setFitHeight(100);
        springImage.setFitWidth(100);

        SceneHeader sh = new SceneHeader();
        Scene sc = sh.createHeaderScene("Spring", 
        "Mechanics is a fundamental branch of physics that studies the motion of objectsand the forces that cause or change this motion.",
        "Spring Mass Simulation", springImage,
        "\"Explore and visualize projectile trajectories in 2D physics. Experiment with angle, velocity, and gravity!",
        e ->{
            HomePage.homePageStage.setScene(cst.initializeSpring());
        });
        return sc;
    }
}